# Pomodoro Calm 时序番茄

基于 React、TypeScript、Vite 与 Tailwind CSS 的专注计时和节奏分析应用。计时、偏好、标签及历史记录保存在浏览器本地。

## 本地运行

需要 Node.js 20.19+ 或 22.12+。

```sh
npm install
npm run dev
```

开发服务器默认运行在 `http://127.0.0.1:3000`。生产构建与类型检查：

```sh
npm run build
npm run lint
```

当前功能不需要 Gemini API 密钥。

## 设计资源

- `public/assets/stitch/stitch_cozy_pomodoro_desktop_app/`：Stitch 导出的六个页面原型（HTML 与 PNG）及两套设计规范。
- `public/assets/aistudio/`：AI Studio 项目随附的参考资源。

Vite 会将 `public/` 下的文件原样提供，并在生产构建时一并复制到 `dist/`。

## GitHub Pages

项目已包含 GitHub Actions 发布工作流。将仓库命名为 `pomodoro-calm` 并推送到 `main` 后，工作流会构建并发布 `dist/`。首次发布时，在仓库的 **Settings → Pages** 中将来源设为 **GitHub Actions**。
