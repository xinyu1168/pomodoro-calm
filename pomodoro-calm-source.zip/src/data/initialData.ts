import { PomodoroSession, TagItem, UserPreferences, SoundscapeItem } from '../types';

export const INITIAL_PREFERENCES: UserPreferences = {
  focusDuration: 25,
  shortBreakDuration: 5,
  longBreakDuration: 15,
  longBreakInterval: 4,
  autoStartNext: true,
  soundBell: true,
  dailyTarget: 8,
  timezoneAutoUpdate: true,
  activeSoundscape: 'wind', // 林间微风 playing by default as shown in design
  soundVolume: 45,
  fadeInOut: true,
  presetScheme: '山间宁谧 (Custom A)'
};

export const INITIAL_TAGS: TagItem[] = [
  { id: 'tag-1', name: '深度工作', color: '#9d3e1a', colorName: '深陶土色', associatedSound: '白波浪' },
  { id: 'tag-2', name: '创意设计', color: '#E28743', colorName: '暖沙橙', associatedSound: '壁炉余烬' },
  { id: 'tag-3', name: '阅读学习', color: '#446554', colorName: '抹茶绿', associatedSound: '林间微风' },
  { id: 'tag-4', name: '代码开发', color: '#788696', colorName: '静谧蓝灰', associatedSound: '雨滴窗台' },
  { id: 'tag-5', name: '生活整理', color: '#A2949E', colorName: '淡丁香紫', associatedSound: '春日细雨' }
];

export const SOUNDSCAPES: SoundscapeItem[] = [
  { id: 'rain', name: '春日细雨', type: '48kHz / 3D', icon: 'grain', accentBg: 'bg-secondary-container/50', accentColor: 'text-secondary' },
  { id: 'fire', name: '壁炉余烬', type: '暖烘微响', icon: 'local_fire_department', accentBg: 'bg-primary-fixed', accentColor: 'text-primary' },
  { id: 'wind', name: '林间微风', type: '正在播放', icon: 'air', accentBg: 'bg-secondary', accentColor: 'text-on-secondary', badge: '正在播放' },
  { id: 'wave', name: '白波浪', type: '宽频平抚', icon: 'waves', accentBg: 'bg-surface-container-highest', accentColor: 'text-on-surface' },
  { id: 'window_rain', name: '雨滴窗台', type: '宁静淅沥', icon: 'water_drop', accentBg: 'bg-surface-container-highest', accentColor: 'text-on-surface' },
  { id: 'silent', name: '完全静音', type: '空灵留白', icon: 'cloud_off', accentBg: 'bg-surface-container-highest', accentColor: 'text-on-surface' }
];

export const INITIAL_SESSIONS: PomodoroSession[] = [
  {
    id: 's-1024',
    sessionNumber: 1,
    timeRange: '09:15 - 09:40',
    tag: '深度工作',
    tagColor: '#9d3e1a',
    durationMinutes: 25,
    title: '产品需求梳理与功能边界界定',
    soundscape: '细雨白噪音',
    soundscapeIcon: 'rainy',
    completionRate: '极高完成度 (100%)',
    sessionLabel: 'Session #1024',
    timestamp: '2025-05-14T09:15:00',
    period: 'morning'
  },
  {
    id: 's-1025',
    sessionNumber: 2,
    timeRange: '09:45 - 10:10',
    tag: '深度工作',
    tagColor: '#9d3e1a',
    durationMinutes: 25,
    title: '交互线框绘制 · 桌面端总控面板流转',
    soundscape: '细雨白噪音',
    soundscapeIcon: 'rainy',
    completionRate: '极高完成度',
    sessionLabel: 'Session #1025',
    timestamp: '2025-05-14T09:45:00',
    period: 'morning'
  },
  {
    id: 's-1026',
    sessionNumber: 3,
    timeRange: '10:15 - 10:40',
    tag: '方案构思',
    tagColor: '#b65a41',
    durationMinutes: 25,
    title: '设计方案构思 · 团队周中评审准备材料',
    soundscape: '壁炉柴火',
    soundscapeIcon: 'fireplace',
    completionRate: '提前2分钟理顺要点',
    sessionLabel: 'Session #1026',
    timestamp: '2025-05-14T10:15:00',
    period: 'morning'
  },
  {
    id: 's-1027',
    sessionNumber: 4,
    timeRange: '11:00 - 11:25',
    tag: '个人阅读',
    tagColor: '#446554',
    durationMinutes: 25,
    title: '《设计心理学》第4章与心流体验笔记归档',
    soundscape: '静谧咖啡馆背景音',
    soundscapeIcon: 'local_cafe',
    completionRate: '摘录4条核心概念',
    sessionLabel: 'Session #1027',
    timestamp: '2025-05-14T11:00:00',
    period: 'morning'
  },
  {
    id: 's-1028',
    sessionNumber: 5,
    timeRange: '14:30 - 14:55',
    tag: '深度工作',
    tagColor: '#9d3e1a',
    durationMinutes: 25,
    title: '界面视觉精细化打磨 · 调优纸品质感调色盘',
    soundscape: '白噪音：林间晨风',
    soundscapeIcon: 'waves',
    completionRate: '极高专注',
    sessionLabel: 'Session #1028',
    timestamp: '2025-05-14T14:30:00',
    period: 'afternoon'
  },
  {
    id: 's-1029',
    sessionNumber: 6,
    timeRange: '15:00 - 15:25',
    tag: '深度工作',
    tagColor: '#9d3e1a',
    durationMinutes: 25,
    title: '样式规范整理与组件层级 Tokens 重构',
    soundscape: '白噪音：林间晨风',
    soundscapeIcon: 'waves',
    completionRate: '极高专注',
    sessionLabel: 'Session #1029',
    timestamp: '2025-05-14T15:00:00',
    period: 'afternoon'
  },
  {
    id: 's-1030',
    sessionNumber: 7,
    timeRange: '16:10 - 17:10',
    tag: '总结与复盘',
    tagColor: '#8a726a',
    durationMinutes: 50,
    title: '设计走查清单归档，生成今日明细日报并同步工单',
    soundscape: '白噪音：细雨',
    soundscapeIcon: 'rainy',
    completionRate: '今日既定计划全部收尾',
    sessionLabel: 'Session #1030-1031',
    timestamp: '2025-05-14T16:10:00',
    note: '连续冲刺 (50m)',
    period: 'afternoon'
  }
];
