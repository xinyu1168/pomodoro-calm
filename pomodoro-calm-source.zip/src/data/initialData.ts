import { TagItem, UserPreferences, SoundscapeItem } from '../types';

export const INITIAL_PREFERENCES: UserPreferences = {
  focusDuration: 25,
  shortBreakDuration: 5,
  longBreakDuration: 15,
  longBreakInterval: 4,
  autoStartNext: true,
  soundBell: true,
  dailyTarget: 8,
  timezoneAutoUpdate: true,
  activeSoundscape: 'wind', // 林间微风 playing by default as shown in design
  soundVolume: 45,
  fadeInOut: true,
  presetScheme: '山间宁谧 (Custom A)'
};

export const INITIAL_TAGS: TagItem[] = [
  { id: 'tag-1', name: '深度工作', color: '#9d3e1a', colorName: '深陶土色', associatedSound: '白波浪' },
  { id: 'tag-2', name: '创意设计', color: '#E28743', colorName: '暖沙橙', associatedSound: '壁炉余烬' },
  { id: 'tag-3', name: '阅读学习', color: '#446554', colorName: '抹茶绿', associatedSound: '林间微风' },
  { id: 'tag-4', name: '代码开发', color: '#788696', colorName: '静谧蓝灰', associatedSound: '雨滴窗台' },
  { id: 'tag-5', name: '生活整理', color: '#A2949E', colorName: '淡丁香紫', associatedSound: '春日细雨' }
];
export const SOUNDSCAPES: SoundscapeItem[] = [
  { id: 'rain', name: '春日细雨', type: '48kHz / 3D', icon: 'grain', accentBg: 'bg-secondary-container/50', accentColor: 'text-secondary' },
  { id: 'fire', name: '壁炉余烬', type: '暖烘微响', icon: 'local_fire_department', accentBg: 'bg-primary-fixed', accentColor: 'text-primary' },
  { id: 'wind', name: '林间微风', type: '正在播放', icon: 'air', accentBg: 'bg-secondary', accentColor: 'text-on-secondary', badge: '正在播放' },
  { id: 'wave', name: '白波浪', type: '宽频平抚', icon: 'waves', accentBg: 'bg-surface-container-highest', accentColor: 'text-on-surface' },
  { id: 'window_rain', name: '雨滴窗台', type: '宁静淅沥', icon: 'water_drop', accentBg: 'bg-surface-container-highest', accentColor: 'text-on-surface' },
  { id: 'silent', name: '完全静音', type: '空灵留白', icon: 'cloud_off', accentBg: 'bg-surface-container-highest', accentColor: 'text-on-surface' }
];

export const INITIAL_SESSIONS = [];
