/**
 * Procedural ambient soundscape and mindfulness chime generator via Web Audio API.
 * Ensures zero external audio dependency failures.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private noiseNode: AudioNode | null = null;
  private gainNode: GainNode | null = null;
  private isPlaying = false;
  private currentSoundId = 'none';

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public playSoundscape(soundId: string, volume: number = 0.45) {
    this.initContext();
    if (!this.ctx) return;

    this.stopSoundscape();
    if (soundId === 'silent' || soundId === 'none') {
      this.currentSoundId = 'silent';
      return;
    }

    this.currentSoundId = soundId;
    this.isPlaying = true;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(Math.max(0.01, volume * 0.35), this.ctx.currentTime);
    gain.connect(this.ctx.destination);
    this.gainNode = gain;

    // Buffer for noise generation
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);

    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      if (soundId === 'rain' || soundId === 'window_rain') {
        // Pinkish rain noise
        output[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = output[i];
        output[i] *= 3.5;
      } else if (soundId === 'fire') {
        // Crackling fireplace
        const isCrack = Math.random() < 0.002 ? (Math.random() * 2 - 1) * 2.5 : 0;
        output[i] = (lastOut + 0.04 * white) / 1.04 + isCrack;
        lastOut = output[i];
      } else if (soundId === 'wind') {
        // Gentle wind
        output[i] = (lastOut + 0.015 * white) / 1.015;
        lastOut = output[i];
      } else {
        // Waves
        output[i] = (lastOut + 0.03 * white) / 1.03;
        lastOut = output[i];
      }
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    // Lowpass filter for warm, relaxing frequency curve
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    if (soundId === 'rain') {
      filter.frequency.setValueAtTime(1200, this.ctx.currentTime);
    } else if (soundId === 'fire') {
      filter.frequency.setValueAtTime(650, this.ctx.currentTime);
    } else if (soundId === 'wind') {
      filter.frequency.setValueAtTime(450, this.ctx.currentTime);
    } else {
      filter.frequency.setValueAtTime(800, this.ctx.currentTime);
    }

    whiteNoise.connect(filter);
    filter.connect(gain);
    whiteNoise.start();
    this.noiseNode = whiteNoise;
  }

  public setVolume(volume: number) {
    if (this.gainNode && this.ctx) {
      this.gainNode.gain.setValueAtTime(Math.max(0.001, (volume / 100) * 0.4), this.ctx.currentTime);
    }
  }

  public stopSoundscape() {
    if (this.noiseNode) {
      try {
        (this.noiseNode as AudioBufferSourceNode).stop();
        this.noiseNode.disconnect();
      } catch {
        // ignore already stopped
      }
      this.noiseNode = null;
    }
    this.isPlaying = false;
  }

  /**
   * Plays a calming Japanese singing bowl / meditation chime
   */
  public playBowlChime() {
    this.initContext();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(528, now); // 528Hz Solfeggio Love / Miracles frequency
    osc.frequency.exponentialRampToValueAtTime(524, now + 3.5);

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1056, now); // Harmonic overtone
    osc2.frequency.exponentialRampToValueAtTime(1050, now + 2.0);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.3, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 4.5);

    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc2.start(now);
    osc.stop(now + 4.5);
    osc2.stop(now + 4.5);
  }
}

export const soundEngine = new SoundEngine();
