interface Window {
  webkit?: {
    messageHandlers?: {
      pomodoro?: { postMessage: (message: { action: string; enabled?: boolean }) => void };
    };
  };
}
