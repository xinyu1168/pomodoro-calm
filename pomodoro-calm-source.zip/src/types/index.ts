export type NavigationPath = 'focus-timer' | 'weekly-analytics' | 'daily-breakdown' | 'customization-tags';

export interface PomodoroSession {
  id: string;
  sessionNumber: number;
  timeRange: string;
  tag: string;
  tagColor: string;
  durationMinutes: number;
  title: string;
  soundscape: string;
  soundscapeIcon: string;
  completionRate: string;
  sessionLabel: string;
  timestamp: string;
  note?: string;
  period: 'morning' | 'afternoon' | 'evening';
}

export interface TagItem {
  id: string;
  name: string;
  color: string;
  colorName: string;
  associatedSound: string;
}

export interface UserPreferences {
  focusDuration: number;
  shortBreakDuration: number;
  longBreakDuration: number;
  longBreakInterval: number;
  autoStartNext: boolean;
  soundBell: boolean;
  dailyTarget: number;
  timezoneAutoUpdate: boolean;
  activeSoundscape: string;
  soundVolume: number;
  fadeInOut: boolean;
  presetScheme: string;
}

export interface SoundscapeItem {
  id: string;
  name: string;
  type: string;
  icon: string;
  accentBg: string;
  accentColor: string;
  badge?: string;
}
