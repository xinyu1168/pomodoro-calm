import React, { useState, useEffect } from 'react';
import { NavigationPath, PomodoroSession, UserPreferences, TagItem } from './types';
import { INITIAL_PREFERENCES, INITIAL_TAGS, INITIAL_SESSIONS } from './data/initialData';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { FocusTimerView } from './components/views/FocusTimerView';
import { WeeklyAnalyticsView } from './components/views/WeeklyAnalyticsView';
import { DailyBreakdownView } from './components/views/DailyBreakdownView';
import { CustomSettingsView } from './components/views/CustomSettingsView';
import { ManualSessionModal } from './components/ManualSessionModal';

export default function App() {
  const [currentPath, setCurrentPath] = useState<NavigationPath>('focus-timer');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isMiniWindowOpen, setIsMiniWindowOpen] = useState(false);
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);

  // Persistent preferences
  const [preferences, setPreferences] = useState<UserPreferences>(() => {
    try {
      const saved = localStorage.getItem('pomodoro_calm_prefs');
      return saved ? JSON.parse(saved) : INITIAL_PREFERENCES;
    } catch {
      return INITIAL_PREFERENCES;
    }
  });

  // Persistent tags
  const [tags, setTags] = useState<TagItem[]>(() => {
    try {
      const saved = localStorage.getItem('pomodoro_calm_tags');
      return saved ? JSON.parse(saved) : INITIAL_TAGS;
    } catch {
      return INITIAL_TAGS;
    }
  });

  // Persistent sessions
  const [sessions, setSessions] = useState<PomodoroSession[]>(() => {
    try {
      const saved = localStorage.getItem('pomodoro_calm_sessions_v2');
      return saved ? JSON.parse(saved) : INITIAL_SESSIONS;
    } catch {
      return INITIAL_SESSIONS;
    }
  });

  // Completed count for today
  const todayKey = new Date().toLocaleDateString('en-CA');
  const completedTodayCount = sessions.filter((session) => new Date(session.timestamp).toLocaleDateString('en-CA') === todayKey).length;

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('pomodoro_calm_prefs', JSON.stringify(preferences));
    } catch {
      // storage quota or private mode fallback
    }
  }, [preferences]);

  useEffect(() => {
    try {
      localStorage.setItem('pomodoro_calm_tags', JSON.stringify(tags));
    } catch {
      // ignore
    }
  }, [tags]);

  useEffect(() => {
    try {
      localStorage.setItem('pomodoro_calm_sessions_v2', JSON.stringify(sessions));
    } catch {
      // ignore
    }
  }, [sessions]);

  // Session completed in timer
  const handleSessionComplete = (sessionData: Partial<PomodoroSession>) => {
    const nextNum = sessions.length + 1;
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const startStr = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const endMinutes = now.getMinutes() + (sessionData.durationMinutes || 25);
    const endStr = `${pad(now.getHours() + Math.floor(endMinutes / 60))}:${pad(endMinutes % 60)}`;

    const newSession: PomodoroSession = {
      id: `s-${Date.now()}`,
      sessionNumber: nextNum,
      timeRange: `${startStr} - ${endStr}`,
      tag: sessionData.tag || '学习',
      tagColor: sessionData.tagColor || '#5b9eff',
      durationMinutes: sessionData.durationMinutes || 25,
      title: sessionData.title || '深度工作专注',
      soundscape: sessionData.soundscape || '',
      soundscapeIcon: 'waves',
      completionRate: '极高完成度 (100%)',
      sessionLabel: `Session #${1024 + nextNum - 1}`,
      timestamp: now.toISOString(),
      period: now.getHours() < 12 ? 'morning' : 'afternoon'
    };

    setSessions([newSession, ...sessions]);
  };

  // Add tag
  const handleAddTag = (newTag: TagItem) => {
    setTags([...tags, newTag]);
  };

  // Delete tag
  const handleDeleteTag = (id: string) => {
    if (tags.length <= 1) {
      alert('请至少保留一个标签。');
      return;
    }
    setTags(tags.filter((t) => t.id !== id));
  };

  return (
    <div className={`app-shell bg-background font-body-md text-on-surface antialiased min-h-screen selection:bg-primary-fixed selection:text-on-primary-fixed flex flex-col ${isMiniWindowOpen ? 'mini-app-shell' : ''}`}>
      {/* Fixed Sidebar */}
      {!isMiniWindowOpen && <Sidebar
        currentPath={currentPath}
        onNavigate={setCurrentPath}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />}

      {/* Main Container offset by sidebar on desktop */}
      <div className={`app-main flex flex-col min-h-screen w-full ${isMiniWindowOpen ? '' : 'lg:pl-64'}`}>
        {/* Fixed Header */}
        {!isMiniWindowOpen && <Header
          completedCount={completedTodayCount}
          onOpenMiniWindow={() => {
            setCurrentPath('focus-timer');
            setIsMiniWindowOpen(true);
            window.webkit?.messageHandlers?.pomodoro?.postMessage({ action: 'mini', enabled: true });
          }}
          onOpenMobileSidebar={() => setIsMobileSidebarOpen(true)}
        />}

        {/* View Content Stage */}
        <main className={`app-content w-full flex-1 bg-background ${isMiniWindowOpen ? '' : 'pt-20 px-4 sm:px-6 lg:px-space-xl'}`}>
          {(currentPath === 'focus-timer' || isMiniWindowOpen) && (
            <FocusTimerView
              preferences={preferences}
              onSessionComplete={handleSessionComplete}
              completedTodayCount={completedTodayCount}
              miniMode={isMiniWindowOpen}
              sessions={sessions}
              onExitMini={() => {
                setIsMiniWindowOpen(false);
                window.webkit?.messageHandlers?.pomodoro?.postMessage({ action: 'mini', enabled: false });
              }}
            />
          )}

          {currentPath === 'weekly-analytics' && (
            <WeeklyAnalyticsView onNavigate={setCurrentPath} sessions={sessions} />
          )}

          {currentPath === 'daily-breakdown' && (
            <DailyBreakdownView
              sessions={sessions}
              onOpenManualModal={() => setIsManualModalOpen(true)}
            />
          )}

          {currentPath === 'customization-tags' && (
            <CustomSettingsView
              preferences={preferences}
              onUpdatePreferences={setPreferences}
              tags={tags}
              onAddTag={handleAddTag}
              onDeleteTag={handleDeleteTag}
            />
          )}
        </main>
      </div>

      {/* Manual Entry Modal */}
      <ManualSessionModal
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
        onAddSession={(newSession) => setSessions([newSession, ...sessions])}
        tags={tags}
        nextSessionNumber={sessions.length + 1}
      />
    </div>
  );
}
