import React, { useState } from 'react';
import { PomodoroSession, TagItem } from '../types';

interface ManualSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddSession: (session: PomodoroSession) => void;
  tags: TagItem[];
  nextSessionNumber: number;
}

export const ManualSessionModal: React.FC<ManualSessionModalProps> = ({
  isOpen,
  onClose,
  onAddSession,
  tags,
  nextSessionNumber
}) => {
  const [title, setTitle] = useState('');
  const [selectedTag, setSelectedTag] = useState(tags[0]?.name || '深度工作');
  const [startTime, setStartTime] = useState('17:30');
  const [endTime, setEndTime] = useState('17:55');
  const [duration, setDuration] = useState(25);
  const [soundscape, setSoundscape] = useState('细雨白噪音');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const tagObj = tags.find((t) => t.name === selectedTag) || tags[0];

    const newSession: PomodoroSession = {
      id: `s-${Date.now()}`,
      sessionNumber: nextSessionNumber,
      timeRange: `${startTime} - ${endTime}`,
      tag: selectedTag,
      tagColor: tagObj?.color || '#9d3e1a',
      durationMinutes: duration,
      title: title.trim(),
      soundscape: soundscape,
      soundscapeIcon: 'rainy',
      completionRate: '手动补录 (100%)',
      sessionLabel: `Session #${1024 + nextSessionNumber - 1}`,
      timestamp: new Date().toISOString(),
      period: Number(startTime.slice(0, 2)) < 12 ? 'morning' : 'afternoon'
    };

    onAddSession(newSession);
    setTitle('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-surface-container-low rounded-3xl p-space-lg shadow-xl border border-outline-variant/40 flex flex-col gap-space-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-xl">add_task</span>
            <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
              添加遗漏补卡
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-surface-container text-on-surface-variant hover:text-on-surface transition-colors"
          >
            <span className="material-symbols-outlined text-lg">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-space-sm">
          {/* Title */}
          <div className="flex flex-col gap-1">
            <label className="font-label-tag text-label-tag text-on-surface-variant">
              专注任务内容 / 主题
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="例如：系统架构文档修订"
              className="bg-surface px-3 py-2.5 rounded-xl border border-outline-variant/40 font-body-sm text-on-surface focus:outline-none focus:border-primary"
            />
          </div>

          {/* Tag */}
          <div className="flex flex-col gap-1">
            <label className="font-label-tag text-label-tag text-on-surface-variant">
              归属标签
            </label>
            <select
              value={selectedTag}
              onChange={(e) => setSelectedTag(e.target.value)}
              className="bg-surface px-3 py-2.5 rounded-xl border border-outline-variant/40 font-body-sm text-on-surface focus:outline-none focus:border-primary cursor-pointer"
            >
              {tags.map((t) => (
                <option key={t.id} value={t.name}>
                  {t.name} ({t.colorName})
                </option>
              ))}
            </select>
          </div>

          {/* Time range */}
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="font-label-tag text-label-tag text-on-surface-variant">
                起始时间
              </label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="bg-surface px-3 py-2 rounded-xl border border-outline-variant/40 font-label-mono text-sm text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="font-label-tag text-label-tag text-on-surface-variant">
                结束时间
              </label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="bg-surface px-3 py-2 rounded-xl border border-outline-variant/40 font-label-mono text-sm text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          {/* Duration */}
          <div className="flex flex-col gap-1">
            <label className="font-label-tag text-label-tag text-on-surface-variant">
              专注时长 (分钟)
            </label>
            <input
              type="number"
              min="5"
              max="120"
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="bg-surface px-3 py-2 rounded-xl border border-outline-variant/40 font-label-mono text-sm text-on-surface focus:outline-none focus:border-primary"
            />
          </div>

          {/* Soundscape */}
          <div className="flex flex-col gap-1">
            <label className="font-label-tag text-label-tag text-on-surface-variant">
              伴随声景
            </label>
            <select
              value={soundscape}
              onChange={(e) => setSoundscape(e.target.value)}
              className="bg-surface px-3 py-2 rounded-xl border border-outline-variant/40 font-body-sm text-on-surface focus:outline-none focus:border-primary cursor-pointer"
            >
              <option value="细雨白噪音">细雨白噪音</option>
              <option value="壁炉柴火">壁炉柴火</option>
              <option value="白噪音：林间晨风">白噪音：林间晨风</option>
              <option value="静谧咖啡馆背景音">静谧咖啡馆背景音</option>
              <option value="完全静音">完全静音</option>
            </select>
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-2 pt-space-xs mt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl font-body-sm text-on-surface-variant hover:bg-surface-container transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-primary text-white font-body-sm font-semibold hover:bg-primary-container transition-colors shadow-xs"
            >
              确认补卡
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
