import React, { useState } from 'react';

interface MiniWindowModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSwitchToFocus: () => void;
}

export const MiniWindowModal: React.FC<MiniWindowModalProps> = ({
  isOpen,
  onClose,
  onSwitchToFocus
}) => {
  const [subTab, setSubTab] = useState<'timer' | 'stats'>('stats');
  const [statsMode, setStatsMode] = useState<'week' | 'month'>('week');
  const [weekIndex, setWeekIndex] = useState(3);
  const [isPinned, setIsPinned] = useState(true);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      {/* 440px wide floating card styled as macOS / Japandi mini dock widget */}
      <div className="w-full max-w-[460px] bg-surface-container-lowest rounded-3xl shadow-[0_16px_40px_-6px_rgba(234,88,12,0.18),0_4px_16px_rgba(0,0,0,0.08)] border border-outline-variant/40 overflow-hidden flex flex-col min-h-[580px] relative select-none">
        {/* Floating Mini Header */}
        <div className="h-16 px-space-lg flex items-center justify-between border-b border-surface-container-high/60 bg-surface-container-lowest/95 backdrop-blur-md">
          {/* Mac controls */}
          <div className="flex items-center gap-space-xs">
            <button
              onClick={onClose}
              className="w-3 h-3 rounded-full bg-[#f87171] hover:opacity-80 transition-opacity cursor-pointer"
              title="关闭小窗"
            />
            <button
              onClick={onClose}
              className="w-3 h-3 rounded-full bg-[#fbbf24] hover:opacity-80 transition-opacity cursor-pointer"
              title="最小化"
            />
            <button
              onClick={() => setIsPinned(!isPinned)}
              className={`w-3 h-3 rounded-full transition-opacity cursor-pointer flex items-center justify-center ${
                isPinned ? 'bg-primary-container' : 'bg-outline-variant'
              }`}
              title={isPinned ? '已置顶' : '点击置顶'}
            >
              <span className="material-symbols-outlined text-[8px] text-white font-bold">push_pin</span>
            </button>
            <span className="ml-space-sm font-headline-sm text-headline-sm text-on-surface tracking-tight">
              Pomodoro Calm · 小窗
            </span>
          </div>

          {/* Subnav Pill */}
          <nav className="flex items-center bg-surface-container-low p-1 rounded-full border border-outline-variant/20">
            <button
              onClick={() => {
                onSwitchToFocus();
                onClose();
              }}
              className="px-space-md py-1 rounded-full font-body-sm text-body-sm text-on-surface-variant hover:text-on-surface transition-colors"
            >
              专注计时
            </button>
            <button
              onClick={() => setSubTab('stats')}
              className="px-space-md py-1 rounded-full bg-primary-container text-white font-semibold font-headline-sm text-xs shadow-xs"
            >
              统计概览
            </button>
          </nav>

          {/* User Icon */}
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-xs">
            <span className="material-symbols-outlined text-white text-[18px]">person</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="w-full flex-1 p-space-lg flex flex-col justify-between overflow-y-auto">
          <div>
            {/* Back button & Week/Month Switcher */}
            <div className="flex items-center justify-between py-space-xs mb-space-sm">
              <div className="flex items-center gap-space-xs">
                <button
                  onClick={() => {
                    onSwitchToFocus();
                    onClose();
                  }}
                  className="flex items-center gap-1 px-space-sm py-1 rounded-full bg-surface-container hover:bg-surface-container-high transition-all active:scale-95 group text-primary border border-outline-variant/20"
                  title="返回专注时钟"
                >
                  <span className="material-symbols-outlined text-[16px] transition-transform group-hover:-translate-x-0.5">
                    arrow_back_ios_new
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface">返回计时</span>
                </button>
                <span className="font-label-mono text-label-mono text-on-surface-variant bg-surface-container-low px-space-xs py-0.5 rounded-full border border-outline-variant/20">
                  STATS · V2.4
                </span>
              </div>

              {/* Mode Segment Switch */}
              <div className="inline-flex p-1 bg-surface-container-high rounded-full shadow-inner border border-outline-variant/20">
                <button
                  onClick={() => setStatsMode('week')}
                  className={`px-space-md py-1 rounded-full font-body-sm text-body-sm transition-all duration-200 ${
                    statsMode === 'week'
                      ? 'bg-primary-container text-white font-semibold shadow-xs'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  周统计
                </button>
                <button
                  onClick={() => setStatsMode('month')}
                  className={`px-space-md py-1 rounded-full font-body-sm text-body-sm transition-all duration-200 ${
                    statsMode === 'month'
                      ? 'bg-primary-container text-white font-semibold shadow-xs'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  月统计
                </button>
              </div>
            </div>

            {/* Date Carousel Range Picker */}
            <div className="bg-surface-container-lowest rounded-2xl p-space-sm shadow-xs border border-outline-variant/30 flex items-center justify-between mb-space-md">
              <button
                onClick={() => setWeekIndex((prev) => Math.max(1, prev - 1))}
                className="w-7 h-7 rounded-full bg-surface-container-low flex items-center justify-center text-on-surface hover:bg-surface-container-high active:scale-90 transition-all border border-outline-variant/20"
              >
                <span className="material-symbols-outlined text-[16px]">chevron_left</span>
              </button>
              <div className="flex flex-col items-center">
                <div className="font-headline-sm text-headline-sm text-on-surface flex items-center gap-1.5 font-semibold">
                  <span>
                    {statsMode === 'week' ? `2024 年 10 月第 ${weekIndex} 周` : '2024 年 10 月全月'}
                  </span>
                  <span className="material-symbols-outlined text-[14px] text-primary">
                    calendar_month
                  </span>
                </div>
                <span className="font-label-mono text-label-mono text-on-surface-variant">
                  {statsMode === 'week' ? '10月14日 - 10月20日' : '10月1日 - 10月31日'}
                </span>
              </div>
              <button
                onClick={() => setWeekIndex((prev) => Math.min(5, prev + 1))}
                className="w-7 h-7 rounded-full bg-surface-container-low flex items-center justify-center text-on-surface hover:bg-surface-container-high active:scale-90 transition-all border border-outline-variant/20"
              >
                <span className="material-symbols-outlined text-[16px]">chevron_right</span>
              </button>
            </div>

            {/* Summary KPI Cards */}
            <div className="grid grid-cols-3 gap-2 mb-space-md">
              <div className="bg-surface-container-low p-space-sm rounded-2xl border border-outline-variant/20 flex flex-col justify-between">
                <span className="font-label-mono text-label-mono text-on-surface-variant">番茄总量</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="font-timer-digits text-2xl text-primary font-bold">
                    {statsMode === 'week' ? '47' : '118'}
                  </span>
                  <span className="font-label-pill text-xs text-on-surface-variant">个</span>
                </div>
                <div className="flex items-center gap-0.5 mt-1 text-primary">
                  <span className="material-symbols-outlined text-[12px]">trending_up</span>
                  <span className="font-label-mono text-[10px]">+12% 同比</span>
                </div>
              </div>

              <div className="bg-surface-container-low p-space-sm rounded-2xl border border-outline-variant/20 flex flex-col justify-between">
                <span className="font-label-mono text-label-mono text-on-surface-variant">专注时长</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="font-timer-digits text-2xl text-secondary font-bold">
                    {statsMode === 'week' ? '19.5' : '49.2'}
                  </span>
                  <span className="font-label-pill text-xs text-on-surface-variant">小时</span>
                </div>
                <span className="font-label-mono text-[10px] text-on-surface-variant mt-1">
                  日均 {statsMode === 'week' ? '2.8h' : '2.1h'}
                </span>
              </div>

              <div className="bg-surface-container-low p-space-sm rounded-2xl border border-outline-variant/20 flex flex-col justify-between">
                <span className="font-label-mono text-label-mono text-on-surface-variant">日最高</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="font-timer-digits text-2xl text-tertiary font-bold">9</span>
                  <span className="font-label-pill text-xs text-on-surface-variant">个</span>
                </div>
                <span className="font-label-mono text-[10px] text-primary-container font-semibold mt-1">
                  周四达标
                </span>
              </div>
            </div>

            {/* STATS MODE 1: WEEKLY VIEW */}
            {statsMode === 'week' ? (
              <div className="bg-surface-container-lowest rounded-2xl p-space-md border border-outline-variant/30 shadow-xs relative overflow-hidden flex flex-col">
                <div className="flex items-center justify-between mb-space-sm">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-primary-container" />
                    <span className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                      每日专注分布
                    </span>
                  </div>
                  <div className="inline-flex items-center gap-1 px-space-sm py-0.5 bg-secondary-container/40 text-on-secondary-container rounded-full font-label-pill text-[11px] border border-secondary/20 font-semibold">
                    <span className="material-symbols-outlined text-[13px]">workspace_premium</span>
                    <span>目标 6个/日</span>
                  </div>
                </div>

                {/* SVG Chart with Goal Line */}
                <div className="relative w-full h-[180px] flex items-end justify-between px-space-xs pt-space-md pb-space-xs">
                  {/* Goal Reference Line */}
                  <div className="absolute left-0 right-0 top-[65px] flex items-center pointer-events-none z-0">
                    <div className="w-full h-[1px] border-t border-dashed border-primary-container/40" />
                    <span className="absolute right-1 -top-2.5 font-label-mono text-[10px] text-primary font-bold bg-surface-container-lowest px-1">
                      GOAL: 6
                    </span>
                  </div>

                  {/* Days */}
                  {[
                    { day: '周一', count: 6, h: '60%', peak: false },
                    { day: '周二', count: 8, h: '80%', peak: false },
                    { day: '周三', count: 7, h: '70%', peak: false },
                    { day: '周四', count: '9★', h: '90%', peak: true },
                    { day: '周五', count: 5, h: '50%', peak: false },
                    { day: '周六', count: 8, h: '80%', peak: false },
                    { day: '周日', count: 4, h: '40%', peak: false }
                  ].map((bar) => (
                    <div
                      key={bar.day}
                      className="flex flex-col items-center gap-1.5 flex-1 z-10 group cursor-pointer"
                    >
                      <span
                        className={`font-label-mono text-[11px] ${
                          bar.peak ? 'text-primary font-bold' : 'text-on-surface-variant'
                        }`}
                      >
                        {bar.count}
                      </span>
                      <div
                        className={`w-7 rounded-full h-[120px] flex flex-col justify-end p-0.5 overflow-hidden ${
                          bar.peak ? 'bg-secondary-container/40' : 'bg-surface-container-high'
                        }`}
                      >
                        <div
                          className={`w-full rounded-full transition-all duration-500 ${
                            bar.peak
                              ? 'bg-gradient-to-t from-primary-container to-secondary-container shadow-xs'
                              : 'bg-primary-container group-hover:bg-primary shadow-xs'
                          }`}
                          style={{ height: bar.h }}
                        />
                      </div>
                      <span
                        className={`font-body-sm text-xs ${
                          bar.peak ? 'text-primary font-bold' : 'text-on-surface-variant group-hover:text-primary'
                        }`}
                      >
                        {bar.day}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-space-md pt-space-sm bg-surface-container-low/60 rounded-xl p-space-sm flex items-center justify-between border border-outline-variant/20">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-secondary-container" />
                    <span className="font-body-sm text-xs text-on-surface">黄金专注时段</span>
                  </div>
                  <span className="font-label-mono text-xs text-primary font-bold">
                    14:00 - 17:30 (午后高峰)
                  </span>
                </div>
              </div>
            ) : (
              /* STATS MODE 2: MONTHLY VIEW */
              <div className="bg-surface-container-lowest rounded-2xl p-space-md border border-outline-variant/30 shadow-xs flex flex-col">
                <div className="grid grid-cols-7 gap-1 text-center font-label-mono text-xs text-on-surface-variant mb-2 font-semibold">
                  <span>一</span>
                  <span>二</span>
                  <span>三</span>
                  <span>四</span>
                  <span>五</span>
                  <span>六</span>
                  <span className="text-tertiary">日</span>
                </div>

                <div className="grid grid-cols-7 gap-1">
                  {/* Prev month tail */}
                  <div className="flex flex-col items-center justify-center p-1 rounded-lg bg-surface-container-low/30 opacity-40 text-xs">
                    <span>30</span>
                  </div>
                  {/* Oct 1 to 21 */}
                  {[
                    { d: 1, p: 4 },
                    { d: 2, p: 6 },
                    { d: 3, p: 5 },
                    { d: 4, p: 2 },
                    { d: 5, p: 7 },
                    { d: 6, p: 3 },
                    { d: 7, p: 5 },
                    { d: 8, p: 6 },
                    { d: 9, p: 8 },
                    { d: 10, p: 5 },
                    { d: 11, p: 6 },
                    { d: 12, p: 7 },
                    { d: 13, p: 1 },
                    { d: 14, p: 6, active: true },
                    { d: 15, p: 8, active: true },
                    { d: 16, p: 7, active: true },
                    { d: 17, p: 9, active: true, peak: true },
                    { d: 18, p: 5, active: true },
                    { d: 19, p: 8, active: true },
                    { d: 20, p: 4, active: true },
                    { d: 21, p: 0 }
                  ].map((cell) => (
                    <div
                      key={cell.d}
                      className={`flex flex-col items-center justify-center p-1 rounded-lg transition-all text-xs cursor-pointer ${
                        cell.peak
                          ? 'bg-secondary-container shadow-xs font-bold scale-105'
                          : cell.active
                          ? 'bg-primary-fixed/60 font-semibold text-primary'
                          : cell.p > 0
                          ? 'bg-surface-container-low hover:bg-surface-container'
                          : 'bg-surface-container-low/40 text-outline-variant'
                      }`}
                    >
                      <span className="font-label-mono text-[11px]">{cell.d}</span>
                      <span className="font-label-pill text-[10px]">
                        {cell.p > 0 ? `${cell.p}🍅` : '-'}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between mt-space-md pt-space-xs text-on-surface-variant border-t border-surface-container-highest/60 text-xs">
                  <span className="font-label-mono">热力密度:</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-label-mono">少</span>
                    <span className="w-2.5 h-2.5 rounded-sm bg-surface-container-low" />
                    <span className="w-2.5 h-2.5 rounded-sm bg-primary-fixed/40" />
                    <span className="w-2.5 h-2.5 rounded-sm bg-primary-fixed/80" />
                    <span className="w-2.5 h-2.5 rounded-sm bg-secondary-container" />
                    <span className="font-label-mono">多 (9+)</span>
                  </div>
                </div>
              </div>
            )}

            {/* Swipe Return Affordance Bar */}
            <div
              onClick={() => {
                onSwitchToFocus();
                onClose();
              }}
              className="mt-space-md bg-surface-container-low/80 rounded-full p-1.5 flex items-center justify-between cursor-pointer hover:bg-surface-container-high transition-colors border border-outline-variant/30"
            >
              <div className="flex items-center gap-2 pl-space-sm">
                <span className="material-symbols-outlined text-[16px] text-primary animate-pulse">
                  keyboard_double_arrow_right
                </span>
                <span className="font-body-sm text-body-sm text-on-surface font-medium">
                  滑向右侧快速唤醒悬浮圆环
                </span>
              </div>
              <span className="font-label-pill text-label-pill bg-surface-container-lowest px-space-sm py-1 rounded-full text-on-surface-variant shadow-xs border border-outline-variant/20">
                ESC / ⌘1
              </span>
            </div>
          </div>

          {/* Mini Window Footer */}
          <footer className="w-full bg-surface-container-low/70 py-space-sm px-space-md rounded-2xl mt-space-md border border-outline-variant/20">
            <div className="flex flex-col items-center justify-center gap-space-xs">
              <div
                className="w-12 h-1 rounded-full bg-outline-variant hover:bg-primary-container transition-colors cursor-grab"
                title="按住拖拽浮窗位置"
              />
              <div className="flex items-center justify-between w-full font-label-mono text-[10px] text-on-surface-variant">
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-primary-container animate-pulse" />
                  <span>MINI DOCK ACTIVE</span>
                </div>
                <span>440 × 580 · CALM MODE</span>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
};
