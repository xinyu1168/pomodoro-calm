import React, { useMemo, useRef, useState } from 'react';
import { PomodoroSession } from '../types';

interface Props {
  sessions: PomodoroSession[];
  time: string;
  isRunning: boolean;
  onToggle: () => void;
  onReset: () => void;
  onExit: () => void;
}

const mondayOf = (date: Date) => {
  const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  start.setHours(0, 0, 0, 0);
  return start;
};
const keyOf = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

export const MiniWindowModal: React.FC<Props> = ({ sessions, time, isRunning, onToggle, onReset, onExit }) => {
  const [page, setPage] = useState<'timer' | 'stats'>('timer');
  const [period, setPeriod] = useState<'week' | 'month'>('week');
  const touchStart = useRef<number | null>(null);
  const wheelDistance = useRef(0);
  const now = new Date();
  const weekStart = mondayOf(now);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);

  const byDay = useMemo(() => {
    const map = new Map<string, { count: number; minutes: number }>();
    sessions.forEach((session) => {
      const d = new Date(session.timestamp);
      if (Number.isNaN(d.valueOf())) return;
      const key = keyOf(d);
      const item = map.get(key) ?? { count: 0, minutes: 0 };
      item.count += 1;
      item.minutes += session.durationMinutes || 25;
      map.set(key, item);
    });
    return map;
  }, [sessions]);

  const rangeSessions = sessions.filter((session) => {
    const d = new Date(session.timestamp);
    return period === 'week'
      ? d >= weekStart && d < new Date(weekStart.getTime() + 7 * 86400000)
      : d >= monthStart && d <= new Date(now.getFullYear(), now.getMonth(), monthEnd.getDate(), 23, 59, 59, 999);
  });
  const total = rangeSessions.length;
  const minutes = rangeSessions.reduce((sum, s) => sum + (s.durationMinutes || 25), 0);
  const days = period === 'week'
    ? Array.from({ length: 7 }, (_, i) => { const d = new Date(weekStart); d.setDate(d.getDate() + i); return d; })
    : Array.from({ length: monthEnd.getDate() }, (_, i) => new Date(now.getFullYear(), now.getMonth(), i + 1));
  const activeDays = days.map((date) => ({ date, value: byDay.get(keyOf(date)) })).filter((item) => item.value);
  const onTouchStart = (e: React.TouchEvent) => { touchStart.current = e.touches[0]?.clientX ?? null; };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStart.current === null) return;
    const delta = (e.changedTouches[0]?.clientX ?? touchStart.current) - touchStart.current;
    if (Math.abs(delta) > 50) setPage(delta > 0 ? 'stats' : 'timer');
    touchStart.current = null;
  };
  const onWheel = (e: React.WheelEvent) => {
    if (Math.abs(e.deltaX) < Math.abs(e.deltaY) * 1.25) return;
    wheelDistance.current += e.deltaX;
    if (Math.abs(wheelDistance.current) > 60) {
      setPage(wheelDistance.current > 0 ? 'stats' : 'timer');
      wheelDistance.current = 0;
    }
  };

  return (
    <section className="mini-dock" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd} onWheel={onWheel} aria-label="Pomodoro Calm 小窗">
      <header className="mini-topbar">
        <div className="mini-brand"><span>🍅</span><strong>CALM</strong><small>专注计时</small></div>
        <nav className="mini-pages" aria-label="小窗页面">
          <button className={page === 'timer' ? 'active' : ''} onClick={() => setPage('timer')}>计时</button>
          <button className={page === 'stats' ? 'active' : ''} onClick={() => setPage('stats')}>统计</button>
        </nav>
        <button className="mini-exit" onClick={onExit} aria-label="返回完整窗口" title="返回完整窗口">↗</button>
      </header>

      {page === 'timer' ? (
        <div className="mini-timer-page">
          <div className={`mini-time ${isRunning ? 'running' : ''}`}>{time}</div>
          <div className="mini-timer-actions">
            <button onClick={onReset} className="mini-icon-button" aria-label="重置计时">↺</button>
            <button onClick={onToggle} className="mini-primary-button">{isRunning ? '暂停' : '开始专注'}</button>
            <button onClick={() => setPage('stats')} className="mini-icon-button" aria-label="查看统计">→</button>
          </div>
          <div className="mini-hint">向右滑动查看统计</div>
        </div>
      ) : (
        <div className="mini-stats-page">
          <div className="mini-stats-head">
            <div><small>已完成的专注</small><strong>{total}<em> 个</em></strong></div>
            <div><small>累计时长</small><strong>{minutes < 60 ? `${minutes} 分` : `${(minutes / 60).toFixed(1)} 小时`}</strong></div>
            <div className="mini-period-switch">
              <button className={period === 'week' ? 'active' : ''} onClick={() => setPeriod('week')}>周</button>
              <button className={period === 'month' ? 'active' : ''} onClick={() => setPeriod('month')}>月</button>
            </div>
          </div>
          <div className="mini-range-label">{now.getFullYear()}年{now.getMonth() + 1}月 · {period === 'week' ? '本周' : '本月'}</div>
          {activeDays.length ? (
            <div className={`mini-day-list ${period}`}>
              {activeDays.map(({ date, value }) => (
                <div className="mini-day" key={keyOf(date)}>
                  <span>{period === 'week' ? ['周日','周一','周二','周三','周四','周五','周六'][date.getDay()] : `${date.getMonth() + 1}/${date.getDate()}`}</span>
                  <div className="mini-bar-track"><i style={{ width: `${Math.max(8, (value!.count / Math.max(1, ...activeDays.map((d) => d.value!.count))) * 100)}%` }} /></div>
                  <b>{value!.count} 🍅</b>
                </div>
              ))}
            </div>
          ) : <div className="mini-empty">完成第一个番茄后，这里会显示你的统计</div>}
          <button className="mini-back" onClick={() => setPage('timer')}>← 返回倒计时</button>
        </div>
      )}
    </section>
  );
};
