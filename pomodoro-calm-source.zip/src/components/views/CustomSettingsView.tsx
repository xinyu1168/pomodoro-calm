import React, { useState } from 'react';
import { UserPreferences, TagItem } from '../../types';
import { SOUNDSCAPES } from '../../data/initialData';
import { soundEngine } from '../../services/soundEngine';

interface CustomSettingsViewProps {
  preferences: UserPreferences;
  onUpdatePreferences: (updated: UserPreferences) => void;
  tags: TagItem[];
  onAddTag: (tag: TagItem) => void;
  onDeleteTag: (id: string) => void;
}

export const CustomSettingsView: React.FC<CustomSettingsViewProps> = ({
  preferences,
  onUpdatePreferences,
  tags,
  onAddTag,
  onDeleteTag
}) => {
  const [localPrefs, setLocalPrefs] = useState<UserPreferences>({ ...preferences });
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#9d3e1a');
  const [newTagSound, setNewTagSound] = useState('春日细雨');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [lastSavedTime, setLastSavedTime] = useState('今日 14:28:10');

  const paletteColors = [
    { hex: '#9d3e1a', name: '深陶土色' },
    { hex: '#E28743', name: '暖沙橙' },
    { hex: '#446554', name: '抹茶绿' },
    { hex: '#788696', name: '静谧蓝灰' },
    { hex: '#A2949E', name: '淡丁香紫' }
  ];

  const handleSave = () => {
    setSaveStatus('saving');
    setTimeout(() => {
      onUpdatePreferences(localPrefs);
      const now = new Date();
      setLastSavedTime(`今日 ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`);
      setSaveStatus('saved');
      setTimeout(() => {
        setSaveStatus('idle');
      }, 1500);
    }, 400);
  };

  const handleResetDefaults = () => {
    if (window.confirm('确定要恢复为经典的 25m/5m/15m 默认预设配置吗？')) {
      const reset: UserPreferences = {
        ...localPrefs,
        focusDuration: 25,
        shortBreakDuration: 5,
        longBreakDuration: 15,
        longBreakInterval: 4,
        autoStartNext: true,
        soundBell: true,
        dailyTarget: 8,
        soundVolume: 45
      };
      setLocalPrefs(reset);
      onUpdatePreferences(reset);
    }
  };

  const handleAddNewTag = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim()) return;
    const colorObj = paletteColors.find((c) => c.hex === newTagColor) || paletteColors[0];
    onAddTag({
      id: `tag-${Date.now()}`,
      name: newTagName.trim(),
      color: colorObj.hex,
      colorName: colorObj.name,
      associatedSound: newTagSound
    });
    setNewTagName('');
  };

  const handleSoundSelect = (soundId: string) => {
    setLocalPrefs({ ...localPrefs, activeSoundscape: soundId });
    soundEngine.playSoundscape(soundId, localPrefs.soundVolume);
  };

  const handleVolumeChange = (vol: number) => {
    setLocalPrefs({ ...localPrefs, soundVolume: vol });
    soundEngine.setVolume(vol);
  };

  return (
    <div className="flex flex-col w-full pb-20">
      {/* Top Ambient Banner / Breadcrumbs & Scheme */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-space-md mb-space-lg">
        <div className="flex flex-col gap-space-xs">
          <div className="flex items-center gap-space-xs text-on-surface-variant font-label-tag text-label-tag uppercase tracking-widest">
            <span>偏好配置</span>
            <span>/</span>
            <span className="text-primary font-semibold">自定节奏与标签</span>
          </div>
          <h1 className="font-headline-lg text-headline-lg text-on-surface tracking-tight font-semibold">
            自定义番茄模式
          </h1>
          <p className="font-body-md text-body-md text-on-surface-variant max-w-2xl">
            依循日式工坊与北欧极简美学，调和每一次专注心流的呼吸感。定制符合个人生理节奏的专注时长、色彩标签与声学空间。
          </p>
        </div>

        {/* Quick State Snapshot Chip */}
        <div className="flex items-center gap-space-sm bg-surface-container px-space-md py-2.5 rounded-full shadow-xs border border-outline-variant/30 self-start md:self-auto">
          <span className="w-2.5 h-2.5 rounded-full bg-secondary" />
          <span className="font-label-mono text-label-mono text-on-surface">
            当前配置方案：<strong className="font-semibold text-primary">{localPrefs.presetScheme}</strong>
          </span>
          <span className="material-symbols-outlined text-base text-on-surface-variant cursor-pointer hover:text-on-surface">
            expand_more
          </span>
        </div>
      </div>

      {/* Bento Grid Configuration Canvas */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-space-lg">
        {/* LEFT COLUMN: Durations & Cadence (7 Cols) */}
        <div className="xl:col-span-7 flex flex-col gap-space-lg">
          {/* Panel 1: Duration Sliders */}
          <section className="bg-surface-container-low rounded-2xl p-6 sm:p-space-xl shadow-xs border border-outline-variant/30 flex flex-col gap-space-lg relative overflow-hidden">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-space-sm">
                <div className="w-9 h-9 rounded-xl bg-surface-container flex items-center justify-center text-primary border border-outline-variant/20">
                  <span className="material-symbols-outlined text-xl">hourglass_empty</span>
                </div>
                <div>
                  <h2 className="font-headline-sm text-headline-sm text-on-surface">时间韵律调节</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    精准微调专注与间隙的呼吸周期
                  </p>
                </div>
              </div>
              <span className="font-label-mono text-label-mono px-3 py-1 rounded-full bg-surface-container-high text-on-surface-variant border border-outline-variant/20">
                标准节奏: {localPrefs.focusDuration} / {localPrefs.shortBreakDuration} / {localPrefs.longBreakDuration}
              </span>
            </div>

            {/* Slider 1: Focus Duration */}
            <div className="bg-surface rounded-2xl p-space-md shadow-xs border border-outline-variant/20 flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-space-xs">
                  <span className="w-2 h-2 rounded-full bg-primary" />
                  <span className="font-body-md text-body-md font-semibold text-on-surface">
                    单次专注时长 (Focus)
                  </span>
                </div>
                <div className="flex items-baseline gap-1 bg-surface-container-low px-space-md py-1 rounded-xl border border-outline-variant/20">
                  <span className="font-label-mono text-headline-sm text-primary font-bold">
                    {localPrefs.focusDuration}
                  </span>
                  <span className="font-label-mono text-label-mono text-on-surface-variant">分钟</span>
                </div>
              </div>
              <input
                type="range"
                min="10"
                max="90"
                step="5"
                value={localPrefs.focusDuration}
                onChange={(e) =>
                  setLocalPrefs({ ...localPrefs, focusDuration: Number(e.target.value) })
                }
                className="w-full accent-primary h-2 bg-surface-container-highest rounded-lg cursor-pointer"
              />
              <div className="flex justify-between font-label-mono text-label-tag text-on-surface-variant/70 px-1">
                <span>10m 柔和起步</span>
                <span>25m 经典番茄</span>
                <span>50m 沉浸心流</span>
                <span>90m 极限凝思</span>
              </div>
            </div>

            {/* Slider 2: Short Break */}
            <div className="bg-surface rounded-2xl p-space-md shadow-xs border border-outline-variant/20 flex flex-col gap-space-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-space-xs">
                  <span className="w-2 h-2 rounded-full bg-secondary" />
                  <span className="font-body-md text-body-md font-semibold text-on-surface">
                    短休息时长 (Short Break)
                  </span>
                </div>
                <div className="flex items-baseline gap-1 bg-surface-container-low px-space-md py-1 rounded-xl border border-outline-variant/20">
                  <span className="font-label-mono text-headline-sm text-secondary font-bold">
                    {localPrefs.shortBreakDuration}
                  </span>
                  <span className="font-label-mono text-label-mono text-on-surface-variant">分钟</span>
                </div>
              </div>
              <input
                type="range"
                min="3"
                max="15"
                step="1"
                value={localPrefs.shortBreakDuration}
                onChange={(e) =>
                  setLocalPrefs({ ...localPrefs, shortBreakDuration: Number(e.target.value) })
                }
                className="w-full accent-secondary h-2 bg-surface-container-highest rounded-lg cursor-pointer"
              />
              <div className="flex justify-between font-label-mono text-label-tag text-on-surface-variant/70 px-1">
                <span>3m 抿茶润喉</span>
                <span>5m 舒展脊柱</span>
                <span>10m 远眺绿植</span>
                <span>15m 放空闭目</span>
              </div>
            </div>

            {/* Slider 3: Long Break */}
            <div className="bg-surface rounded-2xl p-space-md shadow-xs border border-outline-variant/20 flex flex-col gap-space-md">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-space-xs">
                  <span className="w-2 h-2 rounded-full bg-tertiary" />
                  <span className="font-body-md text-body-md font-semibold text-on-surface">
                    长休息时长 (Long Break)
                  </span>
                </div>
                <div className="flex items-baseline gap-1 bg-surface-container-low px-space-md py-1 rounded-xl border border-outline-variant/20">
                  <span className="font-label-mono text-headline-sm text-tertiary font-bold">
                    {localPrefs.longBreakDuration}
                  </span>
                  <span className="font-label-mono text-label-mono text-on-surface-variant">分钟</span>
                </div>
              </div>
              <input
                type="range"
                min="10"
                max="45"
                step="5"
                value={localPrefs.longBreakDuration}
                onChange={(e) =>
                  setLocalPrefs({ ...localPrefs, longBreakDuration: Number(e.target.value) })
                }
                className="w-full accent-tertiary h-2 bg-surface-container-highest rounded-lg cursor-pointer"
              />

              {/* Cycle Stepper */}
              <div className="pt-space-xs flex items-center justify-between bg-surface-container-low/70 p-space-sm rounded-xl border border-outline-variant/20">
                <div className="flex items-center gap-space-xs">
                  <span className="material-symbols-outlined text-lg text-on-surface-variant">repeat</span>
                  <span className="font-body-sm text-body-sm text-on-surface">长休息触发周期</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      setLocalPrefs({
                        ...localPrefs,
                        longBreakInterval: Math.max(2, localPrefs.longBreakInterval - 1)
                      })
                    }
                    className="w-7 h-7 rounded-full bg-surface shadow-xs font-label-mono text-sm text-on-surface hover:bg-surface-container-high transition-colors border border-outline-variant/20"
                  >
                    -
                  </button>
                  <span className="font-label-mono text-body-md font-bold text-on-surface px-1">
                    {localPrefs.longBreakInterval}
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">个番茄后</span>
                  <button
                    onClick={() =>
                      setLocalPrefs({
                        ...localPrefs,
                        longBreakInterval: Math.min(8, localPrefs.longBreakInterval + 1)
                      })
                    }
                    className="w-7 h-7 rounded-full bg-surface shadow-xs font-label-mono text-sm text-on-surface hover:bg-surface-container-high transition-colors border border-outline-variant/20"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Toggles: Soft Automation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-space-md pt-space-xs">
              <div className="bg-surface rounded-2xl p-space-md shadow-xs border border-outline-variant/20 flex items-center justify-between">
                <div className="flex flex-col pr-space-sm">
                  <span className="font-body-md text-body-md font-semibold text-on-surface">
                    自动开启下个番茄
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    休息结束后无缝进入专注
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localPrefs.autoStartNext}
                    onChange={(e) =>
                      setLocalPrefs({ ...localPrefs, autoStartNext: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-surface-container-highest peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-secondary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all shadow-inner" />
                </label>
              </div>

              <div className="bg-surface rounded-2xl p-space-md shadow-xs border border-outline-variant/20 flex items-center justify-between">
                <div className="flex flex-col pr-space-sm">
                  <span className="font-body-md text-body-md font-semibold text-on-surface">
                    温和颂钵提示音
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    采用天然风铃与木鱼余音
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localPrefs.soundBell}
                    onChange={(e) => {
                      setLocalPrefs({ ...localPrefs, soundBell: e.target.checked });
                      if (e.target.checked) soundEngine.playBowlChime();
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-surface-container-highest peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-primary-container after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all shadow-inner" />
                </label>
              </div>
            </div>
          </section>

          {/* Panel 2: Timezone & Daily Target */}
          <section className="bg-surface-container-low rounded-2xl p-6 sm:p-space-xl shadow-xs border border-outline-variant/30 flex flex-col gap-space-md">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-space-sm">
                <div className="w-9 h-9 rounded-xl bg-surface-container flex items-center justify-center text-secondary border border-outline-variant/20">
                  <span className="material-symbols-outlined text-xl">public</span>
                </div>
                <div>
                  <h2 className="font-headline-sm text-headline-sm text-on-surface">
                    时序地域与目标规划
                  </h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    同步自然日照节律，明确每日清爽预期
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-space-xs text-secondary font-label-mono text-label-tag">
                <span className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
                <span>自动校准中</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-space-md">
              {/* Timezone Card */}
              <div className="bg-surface p-space-md rounded-2xl shadow-xs border border-outline-variant/20 flex flex-col justify-between">
                <div className="flex flex-col gap-1">
                  <span className="font-label-tag text-label-tag text-on-surface-variant uppercase">
                    当前识别网络时区
                  </span>
                  <span className="font-body-md text-body-md font-semibold text-on-surface">
                    (GMT+08:00) 中国标准时间 (CST)
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    与系统时间同步，日光晨昏算法已激活
                  </span>
                </div>
                <div className="flex items-center justify-between mt-space-md pt-space-xs bg-surface-container-low p-space-sm rounded-xl border border-outline-variant/20">
                  <span className="font-body-sm text-body-sm text-on-surface">跨时区漫游自动更新</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={localPrefs.timezoneAutoUpdate}
                      onChange={(e) =>
                        setLocalPrefs({ ...localPrefs, timezoneAutoUpdate: e.target.checked })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-surface-container-highest peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-secondary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all" />
                  </label>
                </div>
              </div>

              {/* Daily Target Setting Card */}
              <div className="bg-surface p-space-md rounded-2xl shadow-xs border border-outline-variant/20 flex flex-col justify-between">
                <div className="flex flex-col gap-1">
                  <span className="font-label-tag text-label-tag text-on-surface-variant uppercase">
                    每日番茄目标
                  </span>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="font-display-timer text-headline-lg font-light text-primary">
                      {localPrefs.dailyTarget}
                    </span>
                    <span className="font-body-md text-body-md text-on-surface-variant">
                      个专注单元 / 约 {(localPrefs.dailyTarget * 0.41).toFixed(1)} 小时
                    </span>
                  </div>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    温和推荐：留出 30% 留白应对不可预期杂务
                  </p>
                </div>

                {/* Target Stepper */}
                <div className="flex items-center justify-between bg-surface-container-low p-space-sm rounded-xl mt-space-md border border-outline-variant/20">
                  <span className="font-body-sm text-body-sm text-on-surface">调整明日目标</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() =>
                        setLocalPrefs({
                          ...localPrefs,
                          dailyTarget: Math.max(1, localPrefs.dailyTarget - 1)
                        })
                      }
                      className="w-7 h-7 rounded-full bg-surface shadow-xs font-label-mono text-sm text-on-surface hover:bg-surface-container-high transition-colors border border-outline-variant/20"
                    >
                      -
                    </button>
                    <span className="font-label-mono text-body-md font-bold text-on-surface px-1">
                      {localPrefs.dailyTarget}
                    </span>
                    <button
                      onClick={() =>
                        setLocalPrefs({
                          ...localPrefs,
                          dailyTarget: Math.min(16, localPrefs.dailyTarget + 1)
                        })
                      }
                      className="w-7 h-7 rounded-full bg-surface shadow-xs font-label-mono text-sm text-on-surface hover:bg-surface-container-high transition-colors border border-outline-variant/20"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* RIGHT COLUMN: Tag Library & Soundscapes (5 Cols) */}
        <div className="xl:col-span-5 flex flex-col gap-space-lg">
          {/* Panel 3: Tag Management Library */}
          <section className="bg-surface-container-low rounded-2xl p-6 sm:p-space-xl shadow-xs border border-outline-variant/30 flex flex-col gap-space-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-sm">
                <div className="w-9 h-9 rounded-xl bg-surface-container flex items-center justify-center text-primary-container border border-outline-variant/20">
                  <span className="material-symbols-outlined text-xl">label</span>
                </div>
                <div>
                  <h2 className="font-headline-sm text-headline-sm text-on-surface">番茄标签库</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    分类归纳每一刻的专注心境
                  </p>
                </div>
              </div>
              <span className="font-label-mono text-label-tag bg-surface-container-high px-2.5 py-1 rounded-full text-on-surface-variant border border-outline-variant/20">
                共 {tags.length} 组活跃标签
              </span>
            </div>

            {/* Existing Tag List */}
            <div className="flex flex-col gap-2">
              {tags.map((tag) => (
                <div
                  key={tag.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-surface hover:bg-surface-container-high transition-all shadow-xs border border-outline-variant/20 group"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="w-3.5 h-3.5 rounded-full shadow-inner ring-1 ring-black/10"
                      style={{ backgroundColor: tag.color }}
                    />
                    <div className="flex flex-col">
                      <span className="font-body-md text-body-md font-semibold text-on-surface">
                        {tag.name}
                      </span>
                      <span className="font-label-mono text-label-tag text-on-surface-variant">
                        {tag.colorName} · 关联：{tag.associatedSound}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onDeleteTag(tag.id)}
                      className="p-1.5 text-on-surface-variant hover:text-error rounded-lg hover:bg-surface-container"
                      title="删除标签"
                    >
                      <span className="material-symbols-outlined text-base">delete_outline</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add Tag Inline Micro-Form */}
            <form
              onSubmit={handleAddNewTag}
              className="bg-surface rounded-2xl p-space-md shadow-xs border border-outline-variant/20 flex flex-col gap-space-sm mt-space-xs"
            >
              <div className="flex items-center justify-between">
                <span className="font-body-md text-body-md font-semibold text-on-surface">
                  添加新标签
                </span>
                <span className="font-label-tag text-label-tag text-on-surface-variant">
                  自定义专属色彩
                </span>
              </div>

              <div className="flex items-center gap-space-sm">
                <input
                  type="text"
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  placeholder="输入标签名称 (如: 论文撰写)"
                  className="flex-1 bg-surface-container-low rounded-xl px-3 py-2 text-on-surface font-body-md placeholder:text-on-surface-variant/50 focus:outline-none focus:ring-1 focus:ring-primary border border-outline-variant/30 text-sm"
                />
                <div className="flex items-center gap-1.5 p-1 bg-surface-container-low rounded-xl border border-outline-variant/30">
                  {paletteColors.map((color) => (
                    <button
                      key={color.hex}
                      type="button"
                      onClick={() => setNewTagColor(color.hex)}
                      className={`w-5 h-5 rounded-full transition-transform ${
                        newTagColor === color.hex ? 'ring-2 ring-primary scale-110' : 'hover:scale-105'
                      }`}
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between gap-space-sm pt-1">
                <div className="flex items-center gap-2 bg-surface-container-low px-2.5 py-1.5 rounded-xl flex-1 border border-outline-variant/30">
                  <span className="material-symbols-outlined text-sm text-on-surface-variant">
                    graphic_eq
                  </span>
                  <select
                    value={newTagSound}
                    onChange={(e) => setNewTagSound(e.target.value)}
                    className="bg-transparent font-body-sm text-body-sm text-on-surface focus:outline-none w-full cursor-pointer"
                  >
                    <option value="春日细雨">关联声音: 春日细雨</option>
                    <option value="壁炉余烬">关联声音: 壁炉余烬</option>
                    <option value="林间微风">关联声音: 林间微风</option>
                    <option value="白波浪">关联声音: 白波浪</option>
                    <option value="雨滴窗台">关联声音: 雨滴窗台</option>
                  </select>
                </div>
                <button
                  type="submit"
                  className="bg-primary text-white font-body-md font-semibold px-4 py-1.5 rounded-xl hover:bg-primary-container transition-colors shadow-xs flex items-center gap-1 shrink-0 text-sm"
                >
                  <span className="material-symbols-outlined text-base">add</span>
                  <span>添加</span>
                </button>
              </div>
            </form>
          </section>

          {/* Panel 4: White Noise & Soundscapes Atmosphere */}
          <section className="bg-surface-container-low rounded-2xl p-6 sm:p-space-xl shadow-xs border border-outline-variant/30 flex flex-col gap-space-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-sm">
                <div className="w-9 h-9 rounded-xl bg-surface-container flex items-center justify-center text-secondary border border-outline-variant/20">
                  <span className="material-symbols-outlined text-xl">nature_people</span>
                </div>
                <div>
                  <h2 className="font-headline-sm text-headline-sm text-on-surface">
                    白噪音与沉浸声境
                  </h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">
                    天然无损录音，屏蔽周遭纷扰
                  </p>
                </div>
              </div>
              <span className="material-symbols-outlined text-on-surface-variant cursor-pointer hover:text-on-surface">
                volume_up
              </span>
            </div>

            {/* Ambience Selector Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {SOUNDSCAPES.map((sound) => {
                const isSelected = localPrefs.activeSoundscape === sound.id;
                return (
                  <div
                    key={sound.id}
                    onClick={() => handleSoundSelect(sound.id)}
                    className={`p-3 rounded-2xl shadow-xs flex flex-col items-center justify-center text-center gap-2 cursor-pointer transition-all border relative group ${
                      isSelected
                        ? 'bg-surface-container-high border-secondary text-secondary'
                        : 'bg-surface hover:bg-surface-container-high border-outline-variant/20 text-on-surface'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-transform group-hover:scale-105 ${
                        isSelected ? 'bg-secondary text-white' : sound.accentBg
                      }`}
                    >
                      <span className="material-symbols-outlined text-xl">{sound.icon}</span>
                    </div>
                    <span className="font-body-md text-body-md font-medium text-on-surface">
                      {sound.name}
                    </span>
                    <span
                      className={`font-label-mono text-label-tag ${
                        isSelected ? 'text-secondary font-semibold' : 'text-on-surface-variant'
                      }`}
                    >
                      {isSelected ? '正在播放' : sound.type}
                    </span>
                    {isSelected && (
                      <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-secondary animate-ping" />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Volume & Fade Controls */}
            <div className="bg-surface p-space-md rounded-2xl shadow-xs border border-outline-variant/20 flex flex-col gap-space-sm mt-space-xs">
              <div className="flex items-center justify-between">
                <span className="font-body-sm text-body-sm font-semibold text-on-surface">
                  声场输出主音量
                </span>
                <span className="font-label-mono text-label-tag text-on-surface-variant">
                  {localPrefs.soundVolume}% 适宜分贝
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={localPrefs.soundVolume}
                onChange={(e) => handleVolumeChange(Number(e.target.value))}
                className="w-full accent-secondary h-1.5 bg-surface-container-highest rounded-lg cursor-pointer"
              />
              <div className="flex items-center justify-between pt-1">
                <span className="font-body-sm text-body-sm text-on-surface-variant">
                  番茄开始/结束 5秒平滑淡入淡出
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localPrefs.fadeInOut}
                    onChange={(e) =>
                      setLocalPrefs({ ...localPrefs, fadeInOut: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-surface-container-highest peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-secondary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all" />
                </label>
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Bottom Floating Sticky Action Dock */}
      <div className="sticky bottom-6 mt-space-xl z-30">
        <div className="bg-surface-container-high/90 backdrop-blur-md px-6 py-space-md rounded-2xl shadow-xl border border-outline-variant/40 flex flex-col sm:flex-row items-center justify-between gap-space-md">
          <div className="flex items-center gap-space-md">
            <span className="w-3 h-3 rounded-full bg-secondary" />
            <div className="flex flex-col">
              <span className="font-body-md text-body-md font-semibold text-on-surface">
                所有未保存更改已在本地暂存
              </span>
              <span className="font-label-mono text-label-tag text-on-surface-variant">
                上次持久化存档：{lastSavedTime}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-space-md w-full sm:w-auto justify-end">
            <button
              onClick={handleResetDefaults}
              className="px-space-lg py-2.5 rounded-xl font-body-md font-medium text-on-surface hover:bg-surface-container-highest transition-colors flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-lg">history</span>
              <span>恢复默认设置</span>
            </button>
            <button
              onClick={handleSave}
              className="bg-primary hover:bg-primary-container text-white px-space-xl py-2.5 rounded-xl font-headline-sm text-body-md font-semibold transition-all shadow-md active:scale-95 flex items-center gap-2"
            >
              {saveStatus === 'saving' ? (
                <>
                  <span className="material-symbols-outlined text-lg animate-spin">sync</span>
                  <span>保存中...</span>
                </>
              ) : saveStatus === 'saved' ? (
                <>
                  <span className="material-symbols-outlined text-lg">check</span>
                  <span>已保存设置</span>
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined text-lg">check_circle</span>
                  <span>保存偏好设置</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
