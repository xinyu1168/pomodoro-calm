import React, { useState } from 'react';
import { NavigationPath } from '../../types';

interface WeeklyAnalyticsViewProps {
  onNavigate: (path: NavigationPath) => void;
}

export const WeeklyAnalyticsView: React.FC<WeeklyAnalyticsViewProps> = ({ onNavigate }) => {
  const [selectedPeriod, setSelectedPeriod] = useState<'current' | 'previous'>('current');
  const [hoveredBar, setHoveredBar] = useState<string | null>(null);

  // Weekly bar data
  const weeklyBars = [
    { day: '周一', count: 4, hours: '1.7h', height: '57%', isPeak: false, color: 'bg-primary/80', textColor: 'text-on-surface-variant' },
    { day: '周二', count: 5, hours: '2.1h', height: '71%', isPeak: false, color: 'bg-primary/85', textColor: 'text-on-surface-variant' },
    { day: '周三', count: 6, hours: '2.5h', height: '85%', isPeak: false, color: 'bg-primary-container', textColor: 'text-on-surface-variant' },
    { day: '周四', count: 7, hours: '2.9h', height: '100%', isPeak: true, color: 'bg-primary', textColor: 'text-primary font-semibold' },
    { day: '周五', count: 5, hours: '2.1h', height: '71%', isPeak: false, color: 'bg-primary/85', textColor: 'text-on-surface-variant' },
    { day: '周六', count: 4, hours: '1.7h', height: '57%', isPeak: false, color: 'bg-secondary', textColor: 'text-secondary' },
    { day: '周日', count: 3, hours: '1.2h', height: '42%', isPeak: false, color: 'bg-secondary/80', textColor: 'text-secondary' }
  ];

  // Hourly heat blocks
  const hourlyData = [
    { hour: '06', count: 0, note: '休整', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' },
    { hour: '07', count: 1, note: '晨起', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' },
    { hour: '08', count: 2, note: '轻度阅读', bg: 'bg-primary-fixed-dim/60', text: 'text-on-surface-variant/60' },
    { hour: '09', count: 5, note: '晨间高峰', bg: 'bg-primary-container shadow-sm', text: 'text-primary font-semibold' },
    { hour: '10', count: 6, note: '超高频心流', bg: 'bg-primary shadow-sm', text: 'text-primary font-semibold' },
    { hour: '11', count: 4, note: '深度攻坚', bg: 'bg-primary-container', text: 'text-primary font-semibold' },
    { hour: '12', count: 0, note: '午餐', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' },
    { hour: '13', count: 0, note: '午休', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' },
    { hour: '14', count: 3, note: '回温', bg: 'bg-primary-fixed-dim', text: 'text-on-surface-variant/60' },
    { hour: '15', count: 5, note: '下午高峰', bg: 'bg-primary shadow-sm', text: 'text-primary font-semibold' },
    { hour: '16', count: 4, note: '设计推演', bg: 'bg-primary-container', text: 'text-primary font-semibold' },
    { hour: '17', count: 2, note: '整理归档', bg: 'bg-primary-fixed-dim/70', text: 'text-on-surface-variant/60' },
    { hour: '18', count: 0, note: '晚餐', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' },
    { hour: '19', count: 0, note: '散步散心', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' },
    { hour: '20', count: 2, note: '阅读学习', bg: 'bg-secondary-container', text: 'text-secondary font-medium' },
    { hour: '21', count: 2, note: '一日复盘', bg: 'bg-secondary', text: 'text-secondary font-medium' },
    { hour: '22', count: 0, note: '睡前留白', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' },
    { hour: '23', count: 0, note: '就寝休息', bg: 'bg-surface-container-high', text: 'text-on-surface-variant/60' }
  ];

  // Daily cards at bottom
  const dailyCards = [
    { date: '4月14日 · 周一', count: '4 组', desc: '1.7 小时 · 达成', active: false, dotColor: 'bg-primary/70' },
    { date: '4月15日 · 周二', count: '5 组', desc: '2.1 小时 · 达成', active: false, dotColor: 'bg-primary/80' },
    { date: '4月16日 · 周三', count: '6 组', desc: '2.5 小时 · 超额', active: false, dotColor: 'bg-primary' },
    { date: '4月17日 · 周四', count: '7 组', desc: '2.9 小时 · 极佳峰值', active: true, dotColor: 'bg-primary' },
    { date: '4月18日 · 周五', count: '5 组', desc: '2.1 小时 · 达成', active: false, dotColor: 'bg-primary/80' },
    { date: '4月19日 · 周六', count: '4 组', desc: '1.7 小时 · 轻量', active: false, dotColor: 'bg-secondary' },
    { date: '4月20日 · 今日', count: '3 组', desc: '1.2 小时 · 静心', active: false, dotColor: 'bg-secondary' }
  ];

  return (
    <div className="flex flex-col w-full pb-16">
      {/* Top Meta & Title Bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-space-md pt-2 pb-space-lg">
        <div className="flex flex-col gap-space-xs">
          <div className="flex items-center gap-space-xs">
            <span className="font-label-tag text-label-tag text-primary uppercase tracking-widest bg-primary-fixed/60 text-on-primary-fixed px-2 py-0.5 rounded-full">
              数据洞察报告
            </span>
            <span className="font-label-mono text-label-mono text-on-surface-variant/70">
              W16 · 2025春季周期
            </span>
          </div>

          <div className="flex items-baseline gap-space-sm flex-wrap">
            <span className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">
              本周专注总量：34 个番茄
            </span>
            <span className="font-headline-sm text-headline-sm text-on-surface-variant font-normal">
              （约 14.2 小时）
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-on-surface-variant/75 font-label-mono text-body-sm mt-0.5">
            <span className="material-symbols-outlined text-sm text-secondary">public</span>
            <span>时区：Asia/Shanghai (GMT+08:00) · 统计已根据本地时区自动同步校准</span>
          </div>
        </div>

        {/* Date Selector & Scope Switch */}
        <div className="flex items-center gap-space-xs bg-surface-container-high p-1 rounded-xl self-start md:self-end border border-outline-variant/30">
          <button
            onClick={() => setSelectedPeriod('current')}
            className={`px-space-md py-1.5 rounded-lg font-body-sm transition-all ${
              selectedPeriod === 'current'
                ? 'bg-surface-container-lowest text-on-surface font-semibold shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            本周 (4.14 - 4.20)
          </button>
          <button
            onClick={() => setSelectedPeriod('previous')}
            className={`px-space-md py-1.5 rounded-lg font-body-sm transition-colors ${
              selectedPeriod === 'previous'
                ? 'bg-surface-container-lowest text-on-surface font-semibold shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            上周对比
          </button>
          <button
            className="p-1.5 rounded-lg text-on-surface-variant hover:bg-surface-container text-body-sm flex items-center justify-center transition-colors"
            title="选择周期"
          >
            <span className="material-symbols-outlined text-sm">calendar_month</span>
          </button>
        </div>
      </div>

      {/* Bento Grid Main Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-lg">
        {/* Left Column: Primary Weekly Volume & Heatmap (8 Cols) */}
        <div className="lg:col-span-8 flex flex-col gap-space-lg">
          {/* Chart Pod: Weekly Pomodoro Bar Chart */}
          <div className="bg-surface-container-low rounded-2xl p-space-xl shadow-[0_2px_12px_rgba(45,41,38,0.03)] border border-outline-variant/30 flex flex-col justify-between relative overflow-hidden">
            <div className="flex items-center justify-between mb-space-lg">
              <div className="flex flex-col">
                <span className="font-headline-sm text-headline-sm text-on-surface">每日番茄节奏走向</span>
                <span className="font-body-sm text-body-sm text-on-surface-variant">
                  连续达成预定节奏 5 天 · 峰值周四达 7 个
                </span>
              </div>
              <div className="flex items-center gap-space-sm font-label-mono text-label-tag">
                <span className="flex items-center gap-1.5 text-on-surface-variant">
                  <span className="w-2.5 h-2.5 rounded-sm bg-primary-container" />
                  达成数
                </span>
                <span className="flex items-center gap-1.5 text-on-surface-variant/60">
                  <span className="w-2.5 h-2.5 rounded-sm bg-surface-variant" />
                  基准目标 (5)
                </span>
              </div>
            </div>

            {/* Inline SVG Stylized Bars */}
            <div className="w-full h-56 flex items-end justify-between px-space-sm relative">
              {/* Baseline target dotted marker line */}
              <div className="absolute left-0 right-0 top-[38%] border-b border-dashed border-outline-variant/60 pointer-events-none flex justify-end pr-2 z-0">
                <span className="font-label-mono text-label-tag text-outline-variant -mt-4 bg-surface-container-low px-1">
                  目标基准线 5 组
                </span>
              </div>

              {weeklyBars.map((bar, idx) => (
                <div
                  key={bar.day}
                  onMouseEnter={() => setHoveredBar(bar.day)}
                  onMouseLeave={() => setHoveredBar(null)}
                  className="group flex flex-col items-center gap-space-xs flex-1 cursor-pointer z-10"
                >
                  <div
                    className={`transition-opacity duration-200 bg-inverse-surface text-inverse-on-surface font-label-mono text-label-tag py-1 px-2 rounded-md shadow-md mb-1 whitespace-nowrap ${
                      hoveredBar === bar.day ? 'opacity-100' : 'opacity-0'
                    }`}
                  >
                    {bar.day}: {bar.count} 组 ({bar.hours})
                  </div>

                  <div className="w-8 md:w-11 h-44 flex items-end justify-center">
                    <div
                      className={`w-full ${bar.color} group-hover:scale-105 transition-all rounded-t-lg flex items-end justify-center pb-1 shadow-xs`}
                      style={{ height: bar.height }}
                    >
                      <span className="font-label-mono text-label-tag text-white font-medium">
                        {bar.count}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-0.5 mt-0.5">
                    {bar.isPeak && (
                      <span className="material-symbols-outlined text-xs text-primary">star</span>
                    )}
                    <span className={`font-label-tag text-label-tag ${bar.textColor}`}>
                      {bar.day}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom info strip */}
            <div className="flex items-center justify-between pt-space-md mt-space-md border-t border-surface-container-highest/60 flex-wrap gap-2">
              <div className="flex items-center gap-2 text-on-surface-variant font-body-sm">
                <span className="w-2 h-2 rounded-full bg-secondary" />
                <span>工作日平均 5.4 组，周末转入轻度阅读与修整模式。</span>
              </div>
              <button
                onClick={() => onNavigate('daily-breakdown')}
                className="inline-flex items-center gap-1 font-label-mono text-body-sm text-primary hover:text-primary-container transition-colors group cursor-pointer"
              >
                <span>查看单日专注时段明细</span>
                <span className="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">
                  arrow_forward
                </span>
              </button>
            </div>
          </div>

          {/* Peak Hourly Heatmap Distribution */}
          <div className="bg-surface-container-low rounded-2xl p-space-xl shadow-[0_2px_12px_rgba(45,41,38,0.03)] border border-outline-variant/30 flex flex-col gap-space-md">
            <div className="flex items-start justify-between flex-wrap gap-2">
              <div>
                <span className="font-headline-sm text-headline-sm text-on-surface">
                  24小时心流热力分布 (Peak Distribution)
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                  识别全天深度注意力高地，用于编排重要决策任务
                </p>
              </div>
              <div className="flex items-center gap-space-xs bg-secondary-container/40 text-on-secondary-container px-2.5 py-1 rounded-full font-label-mono text-label-tag">
                <span className="material-symbols-outlined text-xs">bolt</span>
                <span>晨间 09:30 & 下午 15:00 为双峰心流</span>
              </div>
            </div>

            {/* Hourly Heat Grid (06:00 to 23:00) */}
            <div className="grid grid-cols-6 sm:grid-cols-9 md:grid-cols-18 gap-1.5 pt-space-xs">
              {hourlyData.map((item) => (
                <div key={item.hour} className="flex flex-col items-center gap-1 group">
                  <div
                    className={`w-full h-11 rounded-lg ${item.bg} transition-transform hover:scale-110 cursor-pointer`}
                    title={`${item.hour}:00 - ${item.count} 番茄 (${item.note})`}
                  />
                  <span className={`font-label-mono text-[10px] ${item.text}`}>{item.hour}</span>
                </div>
              ))}
            </div>

            {/* Heatmap Insight Annotations */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-space-md pt-space-xs mt-space-xs">
              <div className="flex items-start gap-space-xs bg-surface-container rounded-xl p-space-sm border border-outline-variant/20">
                <span className="material-symbols-outlined text-primary text-base mt-0.5">wb_sunny</span>
                <div className="flex flex-col">
                  <span className="font-body-sm font-semibold text-on-surface">
                    黄金专注区：09:00 - 11:30
                  </span>
                  <span className="font-body-sm text-on-surface-variant">
                    适宜投入高阻力、高系统思考的技术攻关或文本撰写。
                  </span>
                </div>
              </div>
              <div className="flex items-start gap-space-xs bg-surface-container rounded-xl p-space-sm border border-outline-variant/20">
                <span className="material-symbols-outlined text-secondary text-base mt-0.5">
                  filter_vintage
                </span>
                <div className="flex flex-col">
                  <span className="font-body-sm font-semibold text-on-surface">
                    灵感爆发区：14:30 - 16:30
                  </span>
                  <span className="font-body-sm text-on-surface-variant">
                    能量回升迅速，适合架构推演与多方方案视觉草拟。
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Forecast Pod + Tag Breakdown + Zen Note (4 Cols) */}
        <div className="lg:col-span-4 flex flex-col gap-space-lg">
          {/* Intelligent Forecast Card */}
          <div className="bg-surface-container-low rounded-2xl p-space-xl shadow-[0_2px_12px_rgba(45,41,38,0.03)] border border-outline-variant/30 relative overflow-hidden flex flex-col justify-between">
            <div className="absolute -right-6 -bottom-6 w-28 h-28 rounded-full bg-primary/5 pointer-events-none" />
            <div>
              <div className="flex items-center justify-between mb-space-sm">
                <span className="font-label-tag text-label-tag text-primary uppercase tracking-wider flex items-center gap-1 font-semibold">
                  <span className="material-symbols-outlined text-sm">auto_graph</span>
                  智能节奏预估
                </span>
                <span className="font-label-mono text-label-tag bg-surface-container-high text-on-surface-variant px-2 py-0.5 rounded-full">
                  明日建议
                </span>
              </div>
              <div className="mt-space-sm flex flex-col">
                <span className="font-headline-sm text-headline-sm text-on-surface">明日计划 / 预估</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="font-headline-lg text-headline-lg text-primary font-semibold">6</span>
                  <span className="font-headline-sm text-headline-sm text-on-surface font-normal">个番茄</span>
                  <span className="font-body-md text-body-md text-on-surface-variant">（约 2.5 小时）</span>
                </div>
              </div>

              <div className="mt-space-md p-space-sm bg-surface-container rounded-xl flex flex-col gap-1.5 border border-outline-variant/20">
                <div className="flex items-center gap-1 text-on-surface font-body-sm font-medium">
                  <span className="material-symbols-outlined text-xs text-primary">psychology</span>
                  <span>节奏调度匹配建议</span>
                </div>
                <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
                  根据您的生物钟峰值，建议明日上午{' '}
                  <strong className="text-on-surface font-semibold">09:30</strong> 开始排布 3 组深度工作，下午{' '}
                  <strong className="text-on-surface font-semibold">15:00</strong> 安排 2 组方案设计，傍晚留 1 组用于归档复盘。
                </p>
              </div>
            </div>

            <div className="mt-space-lg pt-space-sm flex items-center justify-between border-t border-surface-container-highest/60">
              <span className="font-body-sm text-on-surface-variant">健康负荷指数</span>
              <span className="font-label-mono text-label-mono text-secondary font-medium flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-secondary" /> 适度充实 (88%)
              </span>
            </div>
          </div>

          {/* Category Tag Ratio Breakdown */}
          <div className="bg-surface-container-low rounded-2xl p-space-xl shadow-[0_2px_12px_rgba(45,41,38,0.03)] border border-outline-variant/30 flex flex-col">
            <div className="flex items-center justify-between mb-space-md">
              <div className="flex flex-col">
                <span className="font-headline-sm text-headline-sm text-on-surface">标签时段占比</span>
                <span className="font-body-sm text-body-sm text-on-surface-variant">聚焦方向平衡检视</span>
              </div>
              <span className="material-symbols-outlined text-on-surface-variant text-base">pie_chart</span>
            </div>

            {/* Stacked Bar Representation */}
            <div className="w-full h-3 rounded-full bg-surface-container-highest overflow-hidden flex my-space-xs shadow-inner">
              <div className="h-full bg-primary transition-all" style={{ width: '55%' }} title="深度工作 55%" />
              <div className="h-full bg-primary-container transition-all" style={{ width: '25%' }} title="方案构思 25%" />
              <div className="h-full bg-secondary transition-all" style={{ width: '20%' }} title="个人阅读 20%" />
            </div>

            {/* Tag Breakdown List */}
            <div className="flex flex-col gap-space-sm mt-space-md">
              <div className="flex items-center justify-between p-space-sm rounded-xl hover:bg-surface-container transition-colors">
                <div className="flex items-center gap-space-sm">
                  <span className="w-3 h-3 rounded-full bg-primary" />
                  <div className="flex flex-col">
                    <span className="font-body-md text-body-md text-on-surface font-medium">深度工作</span>
                    <span className="font-label-mono text-label-tag text-on-surface-variant">19 个番茄 · 7.9h</span>
                  </div>
                </div>
                <span className="font-label-mono text-headline-sm font-semibold text-primary">55%</span>
              </div>

              <div className="flex items-center justify-between p-space-sm rounded-xl hover:bg-surface-container transition-colors">
                <div className="flex items-center gap-space-sm">
                  <span className="w-3 h-3 rounded-full bg-primary-container" />
                  <div className="flex flex-col">
                    <span className="font-body-md text-body-md text-on-surface font-medium">方案构思</span>
                    <span className="font-label-mono text-label-tag text-on-surface-variant">9 个番茄 · 3.7h</span>
                  </div>
                </div>
                <span className="font-label-mono text-headline-sm font-semibold text-primary-container">25%</span>
              </div>

              <div className="flex items-center justify-between p-space-sm rounded-xl hover:bg-surface-container transition-colors">
                <div className="flex items-center gap-space-sm">
                  <span className="w-3 h-3 rounded-full bg-secondary" />
                  <div className="flex flex-col">
                    <span className="font-body-md text-body-md text-on-surface font-medium">个人阅读</span>
                    <span className="font-label-mono text-label-tag text-on-surface-variant">6 个番茄 · 2.6h</span>
                  </div>
                </div>
                <span className="font-label-mono text-headline-sm font-semibold text-secondary">20%</span>
              </div>
            </div>

            <div className="mt-space-md p-space-sm bg-surface-container rounded-xl flex items-center justify-between text-on-surface-variant border border-outline-variant/20">
              <span className="font-body-sm">目标配比健康度</span>
              <span className="font-label-tag text-label-tag text-secondary uppercase font-semibold">
                极佳 (Ideal balance)
              </span>
            </div>
          </div>

          {/* Quick Session Log Summary Card */}
          <div
            onClick={() => onNavigate('daily-breakdown')}
            className="bg-surface-container-high rounded-2xl p-space-md flex items-center justify-between border border-outline-variant/30 cursor-pointer hover:bg-surface-container transition-colors shadow-xs group"
          >
            <div className="flex items-center gap-space-sm">
              <div className="w-10 h-10 rounded-full bg-surface-container-lowest flex items-center justify-center text-primary shadow-xs">
                <span className="material-symbols-outlined text-lg">history_edu</span>
              </div>
              <div className="flex flex-col">
                <span className="font-body-md font-semibold text-on-surface">单日日志归档已就绪</span>
                <span className="font-body-sm text-on-surface-variant">本周累计 28 条反思便签</span>
              </div>
            </div>
            <div className="p-2 rounded-lg bg-surface-container-lowest text-on-surface group-hover:text-primary transition-colors flex items-center justify-center shadow-xs">
              <span className="material-symbols-outlined text-sm group-hover:translate-x-0.5 transition-transform">
                chevron_right
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Detail Day Strip (Interactive quick selector bar) */}
      <div className="mt-space-xl bg-surface-container-low rounded-2xl p-space-lg shadow-[0_2px_12px_rgba(45,41,38,0.02)] border border-outline-variant/30">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-md mb-space-md">
          <div>
            <span className="font-headline-sm text-headline-sm text-on-surface">每日明细速览导览</span>
            <span className="font-body-sm text-body-sm text-on-surface-variant ml-2">
              选择具体星期快速切入深度时段回放
            </span>
          </div>
          <button
            onClick={() => onNavigate('daily-breakdown')}
            className="font-label-mono text-body-sm text-primary hover:text-primary-container transition-colors inline-flex items-center gap-1 cursor-pointer"
          >
            <span>进入每日明细全貌视图</span>
            <span className="material-symbols-outlined text-sm">open_in_new</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-space-sm">
          {dailyCards.map((card) => (
            <button
              key={card.date}
              onClick={() => onNavigate('daily-breakdown')}
              className={`flex flex-col p-space-md rounded-xl text-left transition-all group active:scale-98 border ${
                card.active
                  ? 'bg-primary/10 hover:bg-primary/15 border-primary/30 shadow-xs'
                  : 'bg-surface-container hover:bg-surface-container-high border-outline-variant/20'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span
                  className={`font-label-tag text-label-tag ${
                    card.active ? 'text-primary font-semibold' : 'text-on-surface-variant'
                  }`}
                >
                  {card.date}
                </span>
                <span className={`w-2 h-2 rounded-full ${card.dotColor}`} />
              </div>
              <span
                className={`font-headline-sm text-headline-sm mt-1 transition-colors ${
                  card.active ? 'text-primary font-bold' : 'text-on-surface group-hover:text-primary'
                }`}
              >
                {card.count}
              </span>
              <span
                className={`font-label-mono text-body-sm ${
                  card.active ? 'text-primary/80 font-medium' : 'text-on-surface-variant/80'
                }`}
              >
                {card.desc}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
