import React, { useMemo } from 'react';
import { NavigationPath, PomodoroSession } from '../../types';

interface Props {
  onNavigate: (path: NavigationPath) => void;
  sessions: PomodoroSession[];
}
const mondayOf = (date: Date) => {
  const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  start.setHours(0, 0, 0, 0);
  return start;
};

export const WeeklyAnalyticsView: React.FC<Props> = ({ onNavigate, sessions }) => {
  const monday = mondayOf(new Date());
  const days = useMemo(() => Array.from({ length: 7 }, (_, index) => {
    const date = new Date(monday);
    date.setDate(date.getDate() + index);
    const daySessions = sessions.filter((session) => {
      const timestamp = new Date(session.timestamp);
      return timestamp.getFullYear() === date.getFullYear() && timestamp.getMonth() === date.getMonth() && timestamp.getDate() === date.getDate();
    });
    return { date, sessions: daySessions, minutes: daySessions.reduce((sum, item) => sum + (item.durationMinutes || 25), 0) };
  }), [monday.getTime(), sessions]);
  const activeDays = days.filter((day) => day.sessions.length > 0);
  const weekSessions = activeDays.flatMap((day) => day.sessions);
  const totalMinutes = weekSessions.reduce((sum, item) => sum + (item.durationMinutes || 25), 0);
  const hourly = Array.from({ length: 24 }, (_, hour) => weekSessions.filter((session) => new Date(session.timestamp).getHours() === hour).length);
  const peakHour = hourly.reduce((peak, count, hour) => count > hourly[peak] ? hour : peak, 0);
  const maxCount = Math.max(1, ...days.map((day) => day.sessions.length));
  const weekdays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const dateRange = `${monday.getMonth() + 1}月${monday.getDate()}日 – ${days[6].date.getMonth() + 1}月${days[6].date.getDate()}日`;

  return (
    <div className="flex w-full flex-col gap-5 pb-16">
      <header className="flex flex-wrap items-end justify-between gap-4 pt-2">
        <div>
          <span className="rounded-full bg-primary-fixed/60 px-3 py-1 text-xs tracking-wide text-primary">本周真实记录</span>
          <h1 className="mt-3 text-3xl font-semibold text-on-surface">{weekSessions.length} 个番茄</h1>
          <p className="mt-1 text-sm text-on-surface-variant">{dateRange} · 共专注 {totalMinutes < 60 ? `${totalMinutes} 分钟` : `${(totalMinutes / 60).toFixed(1)} 小时`}</p>
        </div>
        <button onClick={() => onNavigate('focus-timer')} className="rounded-xl bg-primary px-5 py-3 text-sm font-medium text-white hover:bg-primary-container">开启专注</button>
      </header>

      {weekSessions.length === 0 ? (
        <section className="grid min-h-72 place-items-center rounded-3xl border border-outline-variant/40 bg-surface-container-low p-8 text-center">
          <div><div className="text-4xl">🍅</div><h2 className="mt-4 text-lg font-semibold">本周还没有完成的番茄</h2><p className="mt-2 text-sm text-on-surface-variant">完成计时后，这里会自动汇总你的周统计。</p></div>
        </section>
      ) : (
        <>
          <section className="rounded-3xl border border-outline-variant/35 bg-surface-container-low p-6 sm:p-8">
            <div className="mb-6 flex items-center justify-between"><div><h2 className="font-semibold">每日专注</h2><p className="mt-1 text-xs text-on-surface-variant">只显示至少完成过一个番茄的日期</p></div><span className="text-xs text-on-surface-variant">峰值 {Math.max(...days.map((day) => day.sessions.length))} 个/日</span></div>
            <div className="flex h-52 items-end gap-3 sm:gap-5">
              {days.filter((day) => day.sessions.length > 0).map((day) => {
                const name = weekdays[(day.date.getDay() + 6) % 7];
                return <div key={day.date.toISOString()} className="flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-2">
                  <span className="text-xs text-on-surface-variant">{day.sessions.length}</span>
                  <div className="flex h-40 w-full items-end rounded-full bg-surface-container-high p-1"><div className="w-full rounded-full bg-primary-container transition-all" style={{ height: `${Math.max(8, day.sessions.length / maxCount * 100)}%` }} /></div>
                  <span className="text-xs text-on-surface-variant">{name}</span>
                </div>;
              })}
            </div>
          </section>
          <section className="rounded-3xl border border-outline-variant/35 bg-surface-container-low p-6 sm:p-8">
            <div className="flex flex-wrap items-center justify-between gap-2"><div><h2 className="font-semibold">完成时段</h2><p className="mt-1 text-xs text-on-surface-variant">按实际完成时间汇总</p></div>{weekSessions.length > 0 && <span className="text-xs text-on-surface-variant">记录最集中的时段：{String(peakHour).padStart(2, '0')}:00</span>}</div>
            <div className="mt-5 grid grid-cols-12 gap-1 sm:grid-cols-24">{hourly.map((count, hour) => count > 0 ? <div key={hour} title={`${hour}:00 · ${count} 个番茄`} className="grid h-12 place-items-center rounded-md bg-primary-container text-xs text-white sm:h-16">{hour}</div> : null)}</div>
          </section>
          <section className="rounded-3xl border border-outline-variant/35 bg-surface-container-low p-6 sm:p-8">
            <h2 className="font-semibold">有记录的日期</h2><div className="mt-4 divide-y divide-outline-variant/30">{activeDays.map((day) => <div key={day.date.toISOString()} className="flex items-center justify-between py-3"><span>{day.date.toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' })}</span><span className="text-sm text-on-surface-variant">{day.sessions.length} 个 · {day.minutes} 分钟</span></div>)}</div>
            <button onClick={() => onNavigate('daily-breakdown')} className="mt-5 text-sm font-medium text-primary">查看每日明细 →</button>
          </section>
        </>
      )}
    </div>
  );
};
