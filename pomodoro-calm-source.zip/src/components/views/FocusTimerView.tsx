import React, { useState, useEffect, useRef } from 'react';
import { UserPreferences, SoundscapeItem, PomodoroSession } from '../../types';
import { SOUNDSCAPES } from '../../data/initialData';
import { soundEngine } from '../../services/soundEngine';
import { MiniWindowModal } from '../MiniWindowModal';

interface FocusTimerViewProps {
  preferences: UserPreferences;
  onSessionComplete: (session: Partial<PomodoroSession>) => void;
  completedTodayCount: number;
  miniMode?: boolean;
  sessions?: PomodoroSession[];
  onExitMini?: () => void;
}

type TimerMode = 'focus' | 'short_break' | 'long_break';

export const FocusTimerView: React.FC<FocusTimerViewProps> = ({
  preferences,
  onSessionComplete,
  completedTodayCount,
  miniMode = false,
  sessions = [],
  onExitMini = () => {}
}) => {
  const [mode, setMode] = useState<TimerMode>('focus');
  const [timeLeft, setTimeLeft] = useState<number>(preferences.focusDuration * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [intention, setIntention] = useState<string>('产品需求梳理与交互原型打磨');
  const [activeSound, setActiveSound] = useState<string>(preferences.activeSoundscape);
  const [isPlayingSound, setIsPlayingSound] = useState<boolean>(false);
  const [tasks, setTasks] = useState<{ id: string; text: string; done: boolean; tag: string }[]>([
    { id: '1', text: '完成时序番茄页面视觉走查与响应式微调', done: true, tag: '深度工作' },
    { id: '2', text: '整理组件层级 Tokens 并对接调色盘', done: false, tag: '深度工作' },
    { id: '3', text: '撰写 2025 春季数据复盘要点便签', done: false, tag: '方案构思' },
    { id: '4', text: '阅读《设计心理学》第 4 章', done: false, tag: '个人阅读' }
  ]);
  const [newTaskInput, setNewTaskInput] = useState<string>('');

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Determine target total duration
  const getTotalSeconds = (m: TimerMode): number => {
    switch (m) {
      case 'focus':
        return preferences.focusDuration * 60;
      case 'short_break':
        return preferences.shortBreakDuration * 60;
      case 'long_break':
        return preferences.longBreakDuration * 60;
    }
  };

  const totalSeconds = getTotalSeconds(mode);

  // Switch modes
  const handleSwitchMode = (newMode: TimerMode) => {
    setIsRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setMode(newMode);
    setTimeLeft(getTotalSeconds(newMode));
  };

  // Timer Tick
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsRunning(false);
            handleFinish();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, mode]);

  // Finish session handler
  const handleFinish = () => {
    if (preferences.soundBell) {
      soundEngine.playBowlChime();
    }

    if (mode === 'focus') {
      onSessionComplete({
        title: intention || '深度工作专注',
        durationMinutes: preferences.focusDuration,
        tag: '深度工作',
        tagColor: '#9d3e1a',
        soundscape: SOUNDSCAPES.find((s) => s.id === activeSound)?.name || '白噪音',
        completionRate: '100%'
      });

      // Switch to break
      if ((completedTodayCount + 1) % preferences.longBreakInterval === 0) {
        handleSwitchMode('long_break');
      } else {
        handleSwitchMode('short_break');
      }
    } else {
      handleSwitchMode('focus');
    }
  };

  // Soundscape toggles
  const handleToggleSound = (soundId: string) => {
    if (activeSound === soundId && isPlayingSound) {
      soundEngine.stopSoundscape();
      setIsPlayingSound(false);
    } else {
      setActiveSound(soundId);
      soundEngine.playSoundscape(soundId, preferences.soundVolume);
      setIsPlayingSound(true);
    }
  };

  // Format time mm:ss
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Progress for circle (0 to 1)
  const progressRatio = (totalSeconds - timeLeft) / totalSeconds;
  const radius = 135;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - progressRatio * circumference;

  if (miniMode) {
    return <MiniWindowModal
      sessions={sessions}
      time={formatTime(timeLeft)}
      isRunning={isRunning}
      onToggle={() => setIsRunning((running) => !running)}
      onReset={() => { setIsRunning(false); setTimeLeft(totalSeconds); }}
      onExit={onExitMini}
    />;
  }

  if (isRunning && mode === 'focus') {
    return (
      <div className="focus-zen-mode">
        <span className="focus-zen-caption">CALM · 专注进行中</span>
        <div className="focus-zen-time">{formatTime(timeLeft)}</div>
        <button className="focus-zen-pause" onClick={() => setIsRunning(false)}>暂停</button>
      </div>
    );
  }

  // Add task
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskInput.trim()) return;
    setTasks([...tasks, { id: String(Date.now()), text: newTaskInput.trim(), done: false, tag: '深度工作' }]);
    setNewTaskInput('');
  };

  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col gap-space-lg pb-16">
      {/* Top Banner / Intention Kicker */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-surface-container-low p-space-lg rounded-2xl border border-outline-variant/30 shadow-xs">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="font-label-tag text-label-tag text-primary uppercase tracking-wider font-semibold">
              静心专注场域 · ZAZEN FOCUS
            </span>
          </div>
          <h1 className="font-headline-md text-headline-md text-on-surface font-semibold">
            时序呼吸，沉浸于当下每分每秒
          </h1>
        </div>

        {/* Mode Segmented Controls */}
        <div className="inline-flex p-1 bg-surface-container-high rounded-full self-start md:self-auto border border-outline-variant/30">
          <button
            onClick={() => handleSwitchMode('focus')}
            className={`px-space-md py-1.5 rounded-full font-body-sm text-body-sm transition-all ${
              mode === 'focus'
                ? 'bg-primary text-white font-semibold shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            专注 ({preferences.focusDuration}m)
          </button>
          <button
            onClick={() => handleSwitchMode('short_break')}
            className={`px-space-md py-1.5 rounded-full font-body-sm text-body-sm transition-all ${
              mode === 'short_break'
                ? 'bg-secondary text-white font-semibold shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            短微歇 ({preferences.shortBreakDuration}m)
          </button>
          <button
            onClick={() => handleSwitchMode('long_break')}
            className={`px-space-md py-1.5 rounded-full font-body-sm text-body-sm transition-all ${
              mode === 'long_break'
                ? 'bg-tertiary text-white font-semibold shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            长休息 ({preferences.longBreakDuration}m)
          </button>
        </div>
      </div>

      {/* Main Grid: Left Pedestal Timer + Right Tasks & Ambience */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-lg items-start">
        {/* CENTER / LEFT TIMER PEDESTAL (7 cols) */}
        <div className="lg:col-span-7 bg-surface-container-low rounded-2xl p-6 sm:p-space-xl border border-outline-variant/30 shadow-sm flex flex-col items-center justify-center relative overflow-hidden">
          {/* Subtle warm backdrop glow */}
          <div
            className={`absolute -top-20 -left-20 w-64 h-64 rounded-full pointer-events-none transition-all duration-700 blur-3xl opacity-30 ${
              mode === 'focus' ? 'bg-primary/20' : 'bg-secondary/20'
            }`}
          />

          {/* Current Intention Banner */}
          <div className="w-full max-w-md mb-6 flex flex-col items-center">
            <span className="font-label-tag text-label-tag text-on-surface-variant/70 uppercase tracking-widest mb-1.5">
              {mode === 'focus' ? '当前专注目标' : '休息调节心境'}
            </span>
            <input
              type="text"
              value={intention}
              onChange={(e) => setIntention(e.target.value)}
              placeholder="此刻打算投入什么..."
              className="w-full text-center font-headline-sm text-headline-sm text-on-surface bg-transparent border-b border-dashed border-outline-variant/60 focus:border-primary focus:outline-none pb-1 hover:border-outline transition-colors"
            />
          </div>

          {/* SVG Circular Dial with Tabular Digits */}
          <div className="relative w-72 h-72 sm:w-80 sm:h-80 flex items-center justify-center my-2">
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 320 320">
              {/* Background Track */}
              <circle
                cx="160"
                cy="160"
                r={radius}
                className="stroke-surface-container-highest"
                strokeWidth="8"
                fill="none"
              />
              {/* Active Animated Track */}
              <circle
                cx="160"
                cy="160"
                r={radius}
                stroke={mode === 'focus' ? '#9d3e1a' : '#446554'}
                strokeWidth="8"
                strokeLinecap="round"
                fill="none"
                style={{
                  strokeDasharray: circumference,
                  strokeDashoffset: strokeDashoffset,
                  transition: 'stroke-dashoffset 1s linear'
                }}
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span
                className="font-display-timer text-display-timer-mobile sm:text-display-timer text-on-surface font-light tracking-tight tabular-nums select-none"
                style={{ fontVariantNumeric: 'tabular-nums' }}
              >
                {formatTime(timeLeft)}
              </span>
              <span className="font-label-mono text-label-mono text-on-surface-variant mt-1 flex items-center gap-1.5">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isRunning ? (mode === 'focus' ? 'bg-primary animate-ping' : 'bg-secondary animate-ping') : 'bg-outline-variant'
                  }`}
                />
                {isRunning ? (mode === 'focus' ? '深度心流中' : '舒缓呼吸中') : '已就绪'}
              </span>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center gap-space-md mt-6 flex-wrap justify-center">
            {/* Reset */}
            <button
              onClick={() => {
                setIsRunning(false);
                setTimeLeft(totalSeconds);
              }}
              className="w-12 h-12 rounded-full bg-surface-container hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center transition-all border border-outline-variant/30"
              title="重置当前时段 (R)"
            >
              <span className="material-symbols-outlined text-xl">replay</span>
            </button>

            {/* Main Primary Start/Pause CTA */}
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`px-8 py-3.5 rounded-2xl font-headline-sm text-headline-sm font-semibold transition-all shadow-md active:scale-95 flex items-center gap-2 text-white ${
                mode === 'focus'
                  ? 'bg-primary hover:bg-primary-container shadow-primary/20'
                  : 'bg-secondary hover:bg-secondary/90 shadow-secondary/20'
              }`}
            >
              <span className="material-symbols-outlined text-2xl">
                {isRunning ? 'pause' : 'play_arrow'}
              </span>
              <span>{isRunning ? '暂停计时' : mode === 'focus' ? '开启专注' : '开始休息'}</span>
            </button>

            {/* Skip / Complete */}
            <button
              onClick={handleFinish}
              className="w-12 h-12 rounded-full bg-surface-container hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center transition-all border border-outline-variant/30"
              title="完成并跳过"
            >
              <span className="material-symbols-outlined text-xl">skip_next</span>
            </button>
          </div>

          {/* Subtle status ticker */}
          <div className="mt-8 pt-space-md border-t border-surface-container-highest/60 w-full flex items-center justify-between text-on-surface-variant font-label-mono text-body-sm">
            <span>今日累计完成：{completedTodayCount} 个番茄</span>
            <span>目标：{preferences.dailyTarget} 个</span>
          </div>
        </div>

        {/* RIGHT COLUMN: Tasks & Ambient Soundscapes (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-space-lg">
          {/* Ambient Soundscapes Box */}
          <div className="bg-surface-container-low rounded-2xl p-space-lg border border-outline-variant/30 shadow-xs flex flex-col gap-space-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-xl">waves</span>
                <span className="font-headline-sm text-headline-sm text-on-surface">
                  沉浸白噪音伴奏
                </span>
              </div>
              <span className="font-label-mono text-label-tag text-on-surface-variant">
                {isPlayingSound ? '播放中' : '静音'}
              </span>
            </div>

            {/* Sound chips */}
            <div className="grid grid-cols-3 gap-2">
              {SOUNDSCAPES.map((sound) => {
                const isActive = activeSound === sound.id;
                return (
                  <button
                    key={sound.id}
                    onClick={() => handleToggleSound(sound.id)}
                    className={`p-2.5 rounded-xl flex flex-col items-center justify-center text-center gap-1 transition-all border ${
                      isActive && isPlayingSound
                        ? 'bg-secondary text-white border-secondary shadow-xs scale-102'
                        : 'bg-surface hover:bg-surface-container-high text-on-surface border-outline-variant/30'
                    }`}
                  >
                    <span className="material-symbols-outlined text-lg">{sound.icon}</span>
                    <span className="font-body-sm text-body-sm font-medium">{sound.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Today Tasks Checklist */}
          <div className="bg-surface-container-low rounded-2xl p-space-lg border border-outline-variant/30 shadow-xs flex flex-col gap-space-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-xl">checklist</span>
                <span className="font-headline-sm text-headline-sm text-on-surface">
                  待办心流清单
                </span>
              </div>
              <span className="font-label-mono text-label-tag text-on-surface-variant">
                {tasks.filter((t) => t.done).length} / {tasks.length} 已完成
              </span>
            </div>

            {/* Task list */}
            <div className="flex flex-col gap-2 max-h-60 overflow-y-auto">
              {tasks.map((task) => (
                <div
                  key={task.id}
                  onClick={() => {
                    setTasks(
                      tasks.map((t) => (t.id === task.id ? { ...t, done: !t.done } : t))
                    );
                  }}
                  className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer transition-all border ${
                    task.done
                      ? 'bg-surface-container/60 opacity-60 border-transparent'
                      : 'bg-surface hover:bg-surface-container-high border-outline-variant/30 shadow-xs'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                        task.done
                          ? 'bg-primary border-primary text-white'
                          : 'border-outline-variant bg-transparent'
                      }`}
                    >
                      {task.done && (
                        <span className="material-symbols-outlined text-xs">check</span>
                      )}
                    </div>
                    <span
                      className={`font-body-md text-body-md ${
                        task.done ? 'line-through text-on-surface-variant' : 'text-on-surface'
                      }`}
                    >
                      {task.text}
                    </span>
                  </div>
                  <span className="font-label-tag text-label-tag px-2 py-0.5 rounded-full bg-surface-container-high text-on-surface-variant">
                    {task.tag}
                  </span>
                </div>
              ))}
            </div>

            {/* Add Task input */}
            <form onSubmit={handleAddTask} className="flex items-center gap-2 pt-2">
              <input
                type="text"
                value={newTaskInput}
                onChange={(e) => setNewTaskInput(e.target.value)}
                placeholder="添加新的专注待办..."
                className="flex-1 bg-surface px-3 py-2 rounded-xl border border-outline-variant/40 text-on-surface font-body-sm text-body-sm focus:outline-none focus:border-primary"
              />
              <button
                type="submit"
                className="px-3.5 py-2 rounded-xl bg-primary text-white font-body-sm font-semibold hover:bg-primary-container transition-colors shadow-xs"
              >
                添加
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
