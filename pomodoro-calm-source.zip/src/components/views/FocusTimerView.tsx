import React, { useEffect, useRef, useState } from 'react';
import { PomodoroSession, UserPreferences } from '../../types';
import { soundEngine } from '../../services/soundEngine';
import { MiniWindowModal } from '../MiniWindowModal';

interface FocusTimerViewProps {
  preferences: UserPreferences;
  onSessionComplete: (session: Partial<PomodoroSession>) => void;
  completedTodayCount: number;
  miniMode?: boolean;
  sessions?: PomodoroSession[];
  onExitMini?: () => void;
}

type TimerMode = 'focus' | 'short_break' | 'long_break';
type TimerPhase = 'focusReady' | 'focusRunning' | 'breakReady' | 'breakRunning';

export const FocusTimerView: React.FC<FocusTimerViewProps> = ({
  preferences,
  onSessionComplete,
  completedTodayCount,
  miniMode = false,
  sessions = [],
  onExitMini = () => {}
}) => {
  const [mode, setMode] = useState<TimerMode>('focus');
  const [phase, setPhase] = useState<TimerPhase>('focusReady');
  const [tagName, setTagName] = useState(() => {
    try { return localStorage.getItem('pomodoro_calm_timer_tag') || '学习'; } catch { return '学习'; }
  });
  const [timeLeft, setTimeLeft] = useState(preferences.focusDuration * 60);
  const completionHandled = useRef(false);
  const holdTimer = useRef<number | null>(null);

  useEffect(() => {
    try { localStorage.setItem('pomodoro_calm_timer_tag', tagName); } catch { /* storage unavailable */ }
  }, [tagName]);

  const focusDuration = Math.max(1, preferences.focusDuration) * 60;
  const breakMode: TimerMode = (completedTodayCount + 1) % Math.max(1, preferences.longBreakInterval) === 0 ? 'long_break' : 'short_break';
  const breakDuration = (mode === 'long_break' ? preferences.longBreakDuration : preferences.shortBreakDuration) * 60;
  const isRunning = phase === 'focusRunning' || phase === 'breakRunning';
  const isFocus = phase === 'focusRunning';

  useEffect(() => {
    if (!isRunning) return;
    const interval = window.setInterval(() => setTimeLeft((seconds) => Math.max(0, seconds - 1)), 1000);
    return () => window.clearInterval(interval);
  }, [isRunning]);

  useEffect(() => {
    if (!isRunning || timeLeft !== 0 || completionHandled.current) return;
    completionHandled.current = true;
    if (phase === 'focusRunning') {
      const nextMode = breakMode;
      const nextDuration = (nextMode === 'long_break' ? preferences.longBreakDuration : preferences.shortBreakDuration) * 60;
      onSessionComplete({
        title: `${tagName}专注`,
        durationMinutes: preferences.focusDuration,
        tag: tagName,
        tagColor: '#5b9eff',
        soundscape: '',
        completionRate: '100%'
      });
      setMode(nextMode);
      setTimeLeft(nextDuration);
      setPhase('breakReady');
    } else {
      setMode('focus');
      setTimeLeft(focusDuration);
      setPhase('focusReady');
    }
    soundEngine.playBowlChime();
  }, [isRunning, timeLeft, phase, breakMode, focusDuration, onSessionComplete, preferences.focusDuration, preferences.longBreakDuration, preferences.shortBreakDuration, preferences.soundBell, tagName]);

  const formatTime = (seconds: number) => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  const startCurrentTimer = () => {
    completionHandled.current = false;
    soundEngine.prepare();
    setPhase(phase === 'breakReady' ? 'breakRunning' : 'focusRunning');
  };
  const abortPomodoro = () => {
    if (holdTimer.current !== null) window.clearTimeout(holdTimer.current);
    holdTimer.current = null;
    completionHandled.current = false;
    setMode('focus');
    setTimeLeft(focusDuration);
    setPhase('focusReady');
  };
  const beginHold = (event: React.PointerEvent<HTMLButtonElement>) => {
    if (!isFocus) return;
    event.preventDefault();
    try { event.currentTarget.setPointerCapture(event.pointerId); } catch { /* capture unsupported */ }
    holdTimer.current = window.setTimeout(abortPomodoro, 1100);
  };
  const endHold = () => {
    if (holdTimer.current !== null) window.clearTimeout(holdTimer.current);
    holdTimer.current = null;
  };
  const abandonControl = isFocus ? (
    <button
      className="focus-abandon"
      aria-label="长按放弃番茄"
      title="按住 1 秒放弃当前番茄"
      onPointerDown={beginHold}
      onPointerUp={endHold}
      onPointerCancel={endHold}
      onContextMenu={(event) => event.preventDefault()}
    >长按放弃番茄</button>
  ) : null;

  if (isRunning) {
    return <div className={`focus-zen-mode ${phase === 'breakRunning' ? 'focus-zen-break' : ''}`}>
      <div className="focus-zen-time">{formatTime(timeLeft)}</div>
      {abandonControl}
    </div>;
  }

  if (miniMode) {
    return <MiniWindowModal
      sessions={sessions}
      time={formatTime(timeLeft)}
      tagName={tagName}
      durationMinutes={mode === 'focus' ? preferences.focusDuration : mode === 'long_break' ? preferences.longBreakDuration : preferences.shortBreakDuration}
      phase={phase}
      onTagChange={setTagName}
      onStart={startCurrentTimer}
      onExit={onExitMini}
    />;
  }

  const isBreakReady = phase === 'breakReady';
  const shownDuration = isBreakReady ? (mode === 'long_break' ? preferences.longBreakDuration : preferences.shortBreakDuration) : preferences.focusDuration;
  return (
    <section className="focus-page">
      <div className="focus-card">
        <div className="focus-time">{formatTime(timeLeft)}</div>
        <label className={`tomato-label ${isBreakReady ? 'rest-label' : ''}`}>
          {isBreakReady ? (
            <><span className="tomato-dot rest-dot" />休息 · {shownDuration} 分钟</>
          ) : (
            <>
              <span className="tomato-dot" />
              <input aria-label="番茄标签" value={tagName} maxLength={12} onChange={(event) => setTagName(event.target.value || '')} onBlur={() => { if (!tagName.trim()) setTagName('学习'); }} />
              <span className="tomato-duration">{shownDuration} 分钟</span>
              <span className="tomato-fruit" aria-hidden="true">🍅</span>
            </>
          )}
        </label>
        <button className="focus-start-button" onClick={startCurrentTimer}>
          {isBreakReady ? '开始休息' : '开始专注'}
        </button>
      </div>
    </section>
  );
};
