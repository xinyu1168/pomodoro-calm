import React, { useState } from 'react';
import { PomodoroSession } from '../../types';

interface DailyBreakdownViewProps {
  sessions: PomodoroSession[];
  onOpenManualModal: () => void;
}

export const DailyBreakdownView: React.FC<DailyBreakdownViewProps> = ({
  sessions,
  onOpenManualModal
}) => {
  const [currentDateIndex, setCurrentDateIndex] = useState(0);
  const [sortOrder, setSortOrder] = useState<'chrono' | 'grouped'>('chrono');

  const dates = [
    '2025年5月14日 星期三',
    '2025年5月15日 星期四',
    '2025年5月16日 星期五'
  ];

  // Calculate metrics
  const totalMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const totalHours = (totalMinutes / 60).toFixed(1);
  const sessionCount = sessions.length;

  // CSV export handler
  const handleExportCSV = () => {
    const headers = ['编号', '时间段', '专注单元', '分类标签', '任务标题', '伴随声景', '完成度'];
    const rows = sessions.map((s) => [
      s.sessionLabel,
      s.timeRange,
      `${s.durationMinutes}分钟`,
      s.tag,
      `"${s.title.replace(/"/g, '""')}"`,
      s.soundscape,
      s.completionRate
    ]);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Pomodoro_Sessions_${dates[currentDateIndex].replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Split sessions into morning and afternoon
  const morningSessions = sessions.filter((s) => s.period === 'morning');
  const afternoonSessions = sessions.filter((s) => s.period === 'afternoon' || s.period === 'evening');

  return (
    <div className="flex flex-col w-full pb-16">
      <div className="py-2 flex flex-col gap-space-lg">
        {/* Top Bar: Date Switcher, Metrics & Export Buttons */}
        <section className="flex flex-col xl:flex-row xl:items-end justify-between gap-space-md bg-surface-container-low p-space-lg rounded-2xl border border-outline-variant/30 shadow-xs">
          <div className="flex flex-col gap-space-xs">
            <div className="flex items-center gap-space-sm flex-wrap">
              <div className="inline-flex items-center bg-surface-container rounded-full p-1 shadow-xs border border-outline-variant/20">
                <button
                  onClick={() => setCurrentDateIndex((prev) => Math.max(0, prev - 1))}
                  className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-container-high text-on-surface-variant transition-colors"
                  title="前一天"
                >
                  <span className="material-symbols-outlined text-base">chevron_left</span>
                </button>
                <div className="px-space-md flex items-center gap-2 text-on-surface">
                  <span className="material-symbols-outlined text-primary text-base">event</span>
                  <span className="font-headline-sm text-headline-sm tracking-tight font-semibold">
                    {dates[currentDateIndex]}
                  </span>
                </div>
                <button
                  onClick={() => setCurrentDateIndex((prev) => Math.min(dates.length - 1, prev + 1))}
                  className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-container-high text-on-surface-variant transition-colors"
                  title="后一天"
                >
                  <span className="material-symbols-outlined text-base">chevron_right</span>
                </button>
              </div>

              <button
                onClick={() => setCurrentDateIndex(0)}
                className="px-3 py-1.5 rounded-full bg-surface-container hover:bg-surface-container-high text-on-surface-variant font-label-tag text-label-tag transition-colors border border-outline-variant/20"
              >
                今日
              </button>
            </div>

            <div className="flex items-center gap-space-md flex-wrap mt-1">
              <span className="font-body-lg text-body-lg text-on-surface">
                今日达成{' '}
                <strong className="font-headline-sm text-primary font-bold">{sessionCount}</strong> 个番茄
                <span className="text-on-surface-variant text-body-md font-body-md ml-1.5">
                  (累计专注 {totalHours} 小时 · {totalMinutes}分钟)
                </span>
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-outline-variant" />
              <span className="font-label-mono text-label-mono text-on-surface-variant opacity-80 flex items-center gap-1">
                <span className="material-symbols-outlined text-xs">public</span>
                记录基准时区：GMT+08:00 (自动校准)
              </span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-space-sm self-start xl:self-auto flex-wrap">
            <button
              onClick={onOpenManualModal}
              className="flex items-center gap-1.5 px-space-md py-2.5 rounded-xl bg-surface-container text-on-surface hover:bg-surface-container-high font-body-md text-body-md transition-all shadow-xs border border-outline-variant/30"
            >
              <span className="material-symbols-outlined text-base text-primary">add_task</span>
              <span>添加遗漏补卡</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-space-md py-2.5 rounded-xl bg-primary text-white hover:bg-primary-container font-body-md text-body-md transition-all shadow-xs"
            >
              <span className="material-symbols-outlined text-base">download</span>
              <span>导出今日记录 (CSV)</span>
            </button>
          </div>
        </section>

        {/* 24H Overview Ribbon */}
        <section className="bg-surface-container p-space-lg rounded-2xl flex flex-col gap-space-sm shadow-xs border border-outline-variant/30">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary text-sm">timelapse</span>
              <span className="font-label-tag text-label-tag text-on-surface-variant uppercase tracking-wider">
                全天24小时心流热度谱
              </span>
            </div>
            <div className="flex items-center gap-space-md font-label-mono text-body-sm text-on-surface-variant flex-wrap">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-primary" />
                专注阶段 (25m)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-secondary" />
                短时微歇 (5m)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-surface-container-high" />
                空白离线
              </span>
            </div>
          </div>

          {/* Linear Timeline Ruler */}
          <div className="relative w-full h-10 bg-surface-container-lowest rounded-xl p-1 flex items-center overflow-hidden border border-outline-variant/20">
            <div className="relative w-full h-full flex items-center">
              {/* Morning Sessions */}
              <div className="absolute h-full rounded-sm bg-primary" style={{ left: '38.5%', width: '1.7%' }} title="09:15-09:40 番茄 #1" />
              <div className="absolute h-full rounded-sm bg-secondary opacity-80" style={{ left: '40.2%', width: '0.4%' }} title="09:40-09:45 休息" />
              <div className="absolute h-full rounded-sm bg-primary" style={{ left: '40.6%', width: '1.7%' }} title="09:45-10:10 番茄 #2" />
              <div className="absolute h-full rounded-sm bg-secondary opacity-80" style={{ left: '42.3%', width: '0.4%' }} title="10:10-10:15 休息" />
              <div className="absolute h-full rounded-sm bg-primary" style={{ left: '42.7%', width: '1.7%' }} title="10:15-10:40 番茄 #3" />
              <div className="absolute h-full rounded-sm bg-secondary opacity-80" style={{ left: '44.4%', width: '1.4%' }} title="10:40-11:00 肩颈拉伸休憩" />
              <div className="absolute h-full rounded-sm bg-primary" style={{ left: '45.8%', width: '1.7%' }} title="11:00-11:25 番茄 #4" />

              {/* Afternoon Sessions */}
              <div className="absolute h-full rounded-sm bg-primary" style={{ left: '60.4%', width: '1.7%' }} title="14:30-14:55 番茄 #5" />
              <div className="absolute h-full rounded-sm bg-secondary opacity-80" style={{ left: '62.1%', width: '0.4%' }} title="14:55-15:00 休息" />
              <div className="absolute h-full rounded-sm bg-primary" style={{ left: '62.5%', width: '1.7%' }} title="15:00-15:25 番茄 #6" />
              <div className="absolute h-full rounded-sm bg-primary" style={{ left: '67.5%', width: '3.8%' }} title="16:10-17:10 番茄 #7-8 冲刺" />
            </div>
          </div>

          {/* Hour Marks */}
          <div className="flex justify-between font-label-mono text-label-tag text-on-surface-variant/70 px-1 select-none">
            <span>00:00</span>
            <span>03:00</span>
            <span>06:00</span>
            <span className="text-primary font-semibold">09:00</span>
            <span>12:00</span>
            <span className="text-primary font-semibold">15:00</span>
            <span>18:00</span>
            <span>21:00</span>
            <span>24:00</span>
          </div>
        </section>

        {/* Main Workspace Split: Left Chronological Feed, Right Ambient Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-lg items-start">
          {/* Chronological Feed (8 Cols) */}
          <section className="lg:col-span-8 flex flex-col gap-space-md">
            <div className="flex items-center justify-between pb-1 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-xl">view_timeline</span>
                <span className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                  番茄时段脉络
                </span>
                <span className="font-label-mono text-label-tag px-2 py-0.5 rounded-full bg-surface-container text-on-surface-variant border border-outline-variant/20">
                  共 {sessions.length} 个记录
                </span>
              </div>
              <div className="flex items-center gap-1 bg-surface-container-high rounded-xl p-0.5 border border-outline-variant/20">
                <button
                  onClick={() => setSortOrder('chrono')}
                  className={`px-2.5 py-1 rounded-lg font-label-tag text-label-tag transition-all ${
                    sortOrder === 'chrono'
                      ? 'bg-surface-container-lowest text-on-surface shadow-xs font-semibold'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  时间正序
                </button>
                <button
                  onClick={() => setSortOrder('grouped')}
                  className={`px-2.5 py-1 rounded-lg font-label-tag text-label-tag transition-all ${
                    sortOrder === 'grouped'
                      ? 'bg-surface-container-lowest text-on-surface shadow-xs font-semibold'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  按分类归并
                </button>
              </div>
            </div>

            {/* Timeline Node List with Spine */}
            <div className="relative pl-6 flex flex-col gap-space-md">
              <div className="absolute left-2.5 top-3 bottom-4 w-0.5 bg-surface-container-highest" />

              {/* Morning Block Badge */}
              <div className="relative flex items-center gap-2 py-1">
                <span className="absolute -left-6 w-5 h-5 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant font-label-mono text-label-tag border border-outline-variant/30">
                  早
                </span>
                <span className="font-label-mono text-label-mono text-on-surface-variant uppercase tracking-wider font-semibold ml-2">
                  晨间专注阶段 ({morningSessions.length} 组)
                </span>
              </div>

              {/* Morning session items */}
              {morningSessions.map((session, idx) => (
                <React.Fragment key={session.id}>
                  <div className="relative group">
                    <div className="absolute -left-[19px] top-4 w-3.5 h-3.5 rounded-full bg-primary ring-4 ring-background" />
                    <div className="bg-surface-container-lowest p-space-md rounded-2xl shadow-xs hover:shadow-md transition-shadow border border-outline-variant/20 flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-space-sm flex-wrap">
                          <span className="font-label-mono text-body-md font-semibold text-on-surface">
                            {session.timeRange}
                          </span>
                          <span className="inline-flex items-center gap-1 font-label-tag text-label-tag px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed">
                            <span>🍅</span> 第{session.sessionNumber}个番茄 · {session.durationMinutes}m
                          </span>
                          <span className="inline-flex items-center gap-1 font-label-tag text-label-tag px-2 py-0.5 rounded-full bg-surface-container-high text-on-surface">
                            {session.tag}
                          </span>
                        </div>
                        <p className="font-body-md text-body-md text-on-surface font-medium">
                          {session.title}
                        </p>
                        <div className="flex items-center gap-space-md text-on-surface-variant font-label-mono text-body-sm mt-0.5">
                          <span className="flex items-center gap-1">
                            <span className="material-symbols-outlined text-sm text-secondary">
                              {session.soundscapeIcon}
                            </span>
                            {session.soundscape}
                          </span>
                          <span>·</span>
                          <span className="flex items-center gap-1 text-secondary font-medium">
                            <span className="material-symbols-outlined text-sm">verified</span>
                            {session.completionRate}
                          </span>
                        </div>
                      </div>

                      <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-1">
                        <span className="font-label-mono text-label-mono text-on-surface-variant opacity-60">
                          {session.sessionLabel}
                        </span>
                        <button
                          className="opacity-0 group-hover:opacity-100 transition-opacity p-1 text-on-surface-variant hover:text-on-surface"
                          title="更多选项"
                        >
                          <span className="material-symbols-outlined text-lg">more_horiz</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Rest Interval Callout after 3rd session */}
                  {idx === 2 && (
                    <div className="relative py-1 flex items-center gap-3">
                      <div className="absolute -left-[17px] w-2.5 h-2.5 rounded-full bg-secondary-fixed-dim" />
                      <div className="bg-secondary-container/40 text-on-secondary-container px-3 py-1.5 rounded-xl font-label-mono text-body-sm flex items-center gap-2 border border-secondary/20">
                        <span className="material-symbols-outlined text-sm">self_improvement</span>
                        <span>10:40 - 11:00 间歇休憩与肩颈拉伸 (20m)</span>
                      </div>
                    </div>
                  )}
                </React.Fragment>
              ))}

              {/* Afternoon Block Badge */}
              <div className="relative flex items-center gap-2 pt-space-sm">
                <span className="absolute -left-6 w-5 h-5 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant font-label-mono text-label-tag border border-outline-variant/30">
                  午
                </span>
                <span className="font-label-mono text-label-mono text-on-surface-variant uppercase tracking-wider font-semibold ml-2">
                  午后深度攻坚 ({afternoonSessions.length} 组)
                </span>
              </div>

              {/* Afternoon session items */}
              {afternoonSessions.map((session) => (
                <div key={session.id} className="relative group">
                  <div className="absolute -left-[19px] top-4 w-3.5 h-3.5 rounded-full bg-primary ring-4 ring-background" />
                  <div className="bg-surface-container-lowest p-space-md rounded-2xl shadow-xs hover:shadow-md transition-shadow border border-outline-variant/20 flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-space-sm flex-wrap">
                        <span className="font-label-mono text-body-md font-semibold text-on-surface">
                          {session.timeRange}
                        </span>
                        <span className="inline-flex items-center gap-1 font-label-tag text-label-tag px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed">
                          <span>🍅</span>{' '}
                          {session.note
                            ? `第7-8个番茄 · ${session.note}`
                            : `第${session.sessionNumber}个番茄 · ${session.durationMinutes}m`}
                        </span>
                        <span className="inline-flex items-center gap-1 font-label-tag text-label-tag px-2 py-0.5 rounded-full bg-surface-container-high text-on-surface">
                          {session.tag}
                        </span>
                      </div>
                      <p className="font-body-md text-body-md text-on-surface font-medium">
                        {session.title}
                      </p>
                      <div className="flex items-center gap-space-md text-on-surface-variant font-label-mono text-body-sm mt-0.5">
                        <span className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-sm text-secondary">
                            {session.soundscapeIcon}
                          </span>
                          {session.soundscape}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1 text-secondary font-medium">
                          <span className="material-symbols-outlined text-sm">verified</span>
                          {session.completionRate}
                        </span>
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-1">
                      <span className="font-label-mono text-label-mono text-on-surface-variant opacity-60">
                        {session.sessionLabel}
                      </span>
                      <button
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 text-on-surface-variant hover:text-on-surface"
                        title="更多选项"
                      >
                        <span className="material-symbols-outlined text-lg">more_horiz</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Sidebar Analytics (4 Cols) */}
          <aside className="lg:col-span-4 flex flex-col gap-space-md">
            {/* Focus Efficiency Card */}
            <div className="bg-surface-container-low p-space-lg rounded-2xl shadow-xs border border-outline-variant/30 flex flex-col gap-space-md">
              <div className="flex items-center justify-between">
                <span className="font-label-tag text-label-tag text-on-surface-variant uppercase tracking-wider">
                  今日专注能效评分
                </span>
                <span className="material-symbols-outlined text-secondary text-lg">bolt</span>
              </div>

              <div className="flex items-center gap-space-md">
                <div className="relative w-20 h-20 flex items-center justify-center shrink-0">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                    <circle
                      className="text-surface-container-highest stroke-current"
                      cx="18"
                      cy="18"
                      fill="none"
                      r="15.5"
                      strokeWidth="3"
                    />
                    <circle
                      className="text-primary stroke-current"
                      cx="18"
                      cy="18"
                      fill="none"
                      r="15.5"
                      strokeDasharray="100"
                      strokeDashoffset="6"
                      strokeLinecap="round"
                      strokeWidth="3"
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="font-headline-sm text-headline-sm font-bold text-on-surface leading-none">
                      94<span className="text-xs font-normal">%</span>
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-0.5">
                  <span className="font-body-md text-body-md font-semibold text-on-surface">
                    极其平稳的心流
                  </span>
                  <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
                    全天中断仅 1 次，中途暂停小于 3 分钟，保持了极佳的呼吸节奏。
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-space-sm pt-2 bg-surface-container rounded-xl p-space-sm border border-outline-variant/20">
                <div className="flex flex-col">
                  <span className="font-label-tag text-label-tag text-on-surface-variant">目标达成率</span>
                  <span className="font-label-mono text-headline-sm text-primary font-bold">100%</span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">计划8组 / 达成8组</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-label-tag text-label-tag text-on-surface-variant">平均单次时长</span>
                  <span className="font-label-mono text-headline-sm text-secondary font-bold">
                    25.0<span className="text-xs font-normal">m</span>
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">标准无衰减节奏</span>
                </div>
              </div>
            </div>

            {/* Tag Distribution Chart */}
            <div className="bg-surface-container-low p-space-lg rounded-2xl shadow-xs border border-outline-variant/30 flex flex-col gap-space-md">
              <div className="flex items-center justify-between">
                <span className="font-label-tag text-label-tag text-on-surface-variant uppercase tracking-wider">
                  今日标签分布 (Tag Breakdown)
                </span>
                <span className="font-label-mono text-label-tag text-on-surface-variant">共 200 分钟</span>
              </div>

              {/* Visual Bar Stack */}
              <div className="w-full h-3 rounded-full overflow-hidden flex bg-surface-container-highest shadow-inner">
                <div className="h-full bg-primary" style={{ width: '62.5%' }} title="深度工作 62.5%" />
                <div className="h-full bg-tertiary" style={{ width: '12.5%' }} title="方案构思 12.5%" />
                <div className="h-full bg-secondary" style={{ width: '12.5%' }} title="个人阅读 12.5%" />
                <div className="h-full bg-outline" style={{ width: '12.5%' }} title="复盘总结 12.5%" />
              </div>

              {/* Breakdown List */}
              <div className="flex flex-col gap-2.5">
                <div className="flex items-center justify-between text-body-md font-body-md">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-primary" />
                    <span className="text-on-surface">深度工作</span>
                  </div>
                  <div className="flex items-center gap-2 font-label-mono">
                    <span className="text-on-surface font-semibold">125 分钟</span>
                    <span className="text-on-surface-variant text-body-sm">(5 组 · 62%)</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-body-md font-body-md">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-tertiary" />
                    <span className="text-on-surface">方案构思</span>
                  </div>
                  <div className="flex items-center gap-2 font-label-mono">
                    <span className="text-on-surface font-semibold">25 分钟</span>
                    <span className="text-on-surface-variant text-body-sm">(1 组 · 13%)</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-body-md font-body-md">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-secondary" />
                    <span className="text-on-surface">个人阅读</span>
                  </div>
                  <div className="flex items-center gap-2 font-label-mono">
                    <span className="text-on-surface font-semibold">25 分钟</span>
                    <span className="text-on-surface-variant text-body-sm">(1 组 · 13%)</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-body-md font-body-md">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-outline" />
                    <span className="text-on-surface">复盘总结</span>
                  </div>
                  <div className="flex items-center gap-2 font-label-mono">
                    <span className="text-on-surface font-semibold">25 分钟</span>
                    <span className="text-on-surface-variant text-body-sm">(1 组 · 13%)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Ambient Noise & Environmental Log */}
            <div className="bg-surface-container-low p-space-lg rounded-2xl shadow-xs border border-outline-variant/30 flex flex-col gap-space-sm">
              <span className="font-label-tag text-label-tag text-on-surface-variant uppercase tracking-wider">
                声景与心境洞察
              </span>
              <div className="flex items-center gap-space-sm pt-1">
                <div className="w-10 h-10 rounded-xl bg-surface-container flex items-center justify-center text-primary border border-outline-variant/20">
                  <span className="material-symbols-outlined text-xl">graphic_eq</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-body-md text-body-md font-medium text-on-surface">
                    偏爱声景：细雨 (Rainfall)
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    共伴随 5 个时段，心率与节拍维持在平缓区间
                  </span>
                </div>
              </div>
            </div>

            {/* Desk Sanctuary Wabi-Sabi Card */}
            <div className="relative overflow-hidden rounded-2xl bg-surface-container p-space-lg shadow-xs border border-outline-variant/30">
              <div className="relative z-10 flex flex-col gap-1">
                <span className="font-label-tag text-label-tag text-primary uppercase font-bold tracking-wider">
                  Wabi-Sabi 每日寄语
                </span>
                <p className="font-body-md text-body-md text-on-surface italic mt-1 leading-relaxed">
                  “心静如水，不急不躁。今日的八次钟鸣，皆化作纸上的踏实印记。”
                </p>
                <div className="mt-space-sm flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-secondary-container flex items-center justify-center text-secondary font-bold text-sm shadow-xs ring-2 ring-surface-container-high overflow-hidden shrink-0">
                    <img
                      className="w-full h-full object-cover"
                      alt="Wabi-Sabi Desk Sanctuary"
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuB-eUvEVWdC4ie1c4um2d2uhw5dEumpWAi4B-VR__YfN2KjeaV2OQgXfz9MEZe53hEF83IFND8WYl53iSIdUO9fa6vrJ_nNs5DWRdZofUzB3954H3pIlanFFWYyw8065vE-gjCeMQ_VU4PY6HefSIITAthiOU36tL5Oo9RAFrNZ4rN0o0JrKJdNRGvPTEEcejn7VnH3LXW1-RU0FhHZueWptyzQco_QmWTfhS2EHVYd3V5qpeh-GKL5"
                      onError={(e) => {
                        (e.currentTarget as HTMLElement).style.display = 'none';
                      }}
                    />
                    <span className="material-symbols-outlined text-lg">spa</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-tag text-label-tag font-semibold text-on-surface">今日定格</span>
                    <span className="font-label-mono text-body-sm text-on-surface-variant">17:15 归档完成</span>
                  </div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};
