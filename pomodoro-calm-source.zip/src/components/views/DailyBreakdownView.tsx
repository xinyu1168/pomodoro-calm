import React, { useMemo, useState } from 'react';
import { PomodoroSession } from '../../types';

interface DailyBreakdownViewProps { sessions: PomodoroSession[]; onOpenManualModal: () => void; }
const localKey = (value: string) => {
  const date = new Date(value);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};

export const DailyBreakdownView: React.FC<DailyBreakdownViewProps> = ({ sessions, onOpenManualModal }) => {
  const [selectedKey, setSelectedKey] = useState('');
  const dateKeys = useMemo(() => [...new Set(sessions.map((session) => localKey(session.timestamp)))].sort((a, b) => b.localeCompare(a)), [sessions]);
  const activeKey = dateKeys.includes(selectedKey) ? selectedKey : dateKeys[0];
  const daySessions = sessions.filter((session) => localKey(session.timestamp) === activeKey).sort((a, b) => a.timestamp.localeCompare(b.timestamp));
  const totalMinutes = daySessions.reduce((sum, session) => sum + (session.durationMinutes || 25), 0);
  const exportCsv = () => {
    const headers = ['时间', '专注时长', '标签', '任务'];
    const rows = daySessions.map((session) => [new Date(session.timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }), `${session.durationMinutes} 分钟`, session.tag, `"${session.title.replace(/"/g, '""')}"`]);
    const blob = new Blob(['\uFEFF' + [headers.join(','), ...rows.map((row) => row.join(','))].join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `Pomodoro_${activeKey || 'sessions'}.csv`; link.click(); URL.revokeObjectURL(url);
  };
  const dateLabel = activeKey ? new Date(`${activeKey}T12:00:00`).toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' }) : '';

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-5 pb-16">
      <header className="flex flex-wrap items-end justify-between gap-4 rounded-3xl border border-outline-variant/35 bg-surface-container-low p-6 sm:p-8">
        <div><span className="text-xs tracking-widest text-primary">每日记录</span><h1 className="mt-2 text-3xl font-semibold">{dateLabel || '专注明细'}</h1><p className="mt-2 text-sm text-on-surface-variant">{daySessions.length} 个番茄 · {totalMinutes} 分钟</p></div>
        <div className="flex flex-wrap gap-2">
          {dateKeys.length > 1 && <select aria-label="选择有记录的日期" value={activeKey} onChange={(event) => setSelectedKey(event.target.value)} className="rounded-xl border border-outline-variant/40 bg-white px-3 py-2 text-sm">{dateKeys.map((key) => <option value={key} key={key}>{key}</option>)}</select>}
          <button onClick={onOpenManualModal} className="rounded-xl border border-outline-variant/40 bg-white px-4 py-2 text-sm">补录番茄</button>
          {daySessions.length > 0 && <button onClick={exportCsv} className="rounded-xl bg-primary px-4 py-2 text-sm text-white">导出 CSV</button>}
        </div>
      </header>
      {daySessions.length === 0 ? (
        <section className="grid min-h-64 place-items-center rounded-3xl border border-outline-variant/35 bg-white p-8 text-center"><div><div className="text-4xl">◷</div><h2 className="mt-4 font-semibold">还没有专注记录</h2><p className="mt-2 text-sm text-on-surface-variant">完成计时或补录一条记录后，明细会显示在这里。</p><button onClick={onOpenManualModal} className="mt-5 rounded-full bg-primary px-5 py-2.5 text-sm text-white">补录记录</button></div></section>
      ) : (
        <section className="rounded-3xl border border-outline-variant/35 bg-white p-6 sm:p-8"><h2 className="font-semibold">专注时段</h2><div className="mt-5 divide-y divide-outline-variant/25">{daySessions.map((session) => <article key={session.id} className="flex items-start gap-4 py-4"><div className="min-w-14 pt-1 font-mono text-sm text-on-surface-variant">{new Date(session.timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}</div><div className="mt-1 h-3 w-3 shrink-0 rounded-full" style={{ background: session.tagColor }} /><div className="min-w-0 flex-1"><h3 className="font-medium">{session.title}</h3><p className="mt-1 text-sm text-on-surface-variant">{session.tag} · {session.durationMinutes} 分钟{session.soundscape ? ` · ${session.soundscape}` : ''}</p>{session.note && <p className="mt-1 text-xs text-on-surface-variant">{session.note}</p>}</div></article>)}</div></section>
      )}
    </div>
  );
};
