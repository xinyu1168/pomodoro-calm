import React, { useState, useEffect } from 'react';

interface HeaderProps {
  completedCount: number;
  onOpenMiniWindow: () => void;
  onOpenMobileSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  completedCount,
  onOpenMiniWindow,
  onOpenMobileSidebar
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="fixed top-0 left-0 lg:left-64 right-0 h-16 bg-surface/90 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.02)] border-b border-outline-variant/30 z-30 flex items-center justify-between px-4 sm:px-6 lg:px-space-xl">
      {/* Left: Mobile hamburger & Logo Lockup */}
      <div className="flex items-center gap-3 sm:gap-space-md">
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-2 -ml-2 rounded-lg text-on-surface-variant hover:bg-surface-container transition-colors"
          title="打开菜单"
        >
          <span className="material-symbols-outlined text-2xl">menu</span>
        </button>

        <div className="flex items-center gap-2.5">
          {/* Zen Tomato Emblem */}
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white shadow-sm ring-2 ring-primary/20 shrink-0">
            <span className="text-base select-none">🍅</span>
          </div>
          <div className="flex items-baseline gap-space-xs">
            <span className="font-headline-sm text-headline-sm text-on-surface font-semibold tracking-tight">
              Pomodoro Calm
            </span>
            <span className="hidden sm:inline font-body-sm text-body-sm text-on-surface-variant opacity-80">
              时序番茄
            </span>
          </div>
        </div>
      </div>

      {/* Right controls: Timezone, Today count, Mini window trigger & Profile */}
      <div className="flex items-center gap-2 sm:gap-space-md">
        {/* Timezone & clock badge */}
        <div className="hidden md:flex items-center gap-space-xs bg-surface-container-high px-space-md py-1 rounded-full text-on-surface-variant font-label-mono text-label-mono border border-outline-variant/20">
          <span className="material-symbols-outlined text-sm text-primary">schedule</span>
          <span>GMT+08:00 北京时间 {currentTime && `· ${currentTime}`}</span>
        </div>

        {/* Today completed badge */}
        <div className="flex items-center gap-space-xs bg-secondary-container/60 text-on-secondary-container px-3 sm:px-space-md py-1 rounded-full font-label-mono text-label-mono">
          <span className="material-symbols-outlined text-sm">local_cafe</span>
          <span>
            今日完成 <strong className="font-semibold text-secondary">{completedCount}</strong> 组
          </span>
        </div>

        {/* Mini Window Toggle Button */}
        <button
          onClick={onOpenMiniWindow}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container hover:bg-primary/10 text-on-surface hover:text-primary transition-all font-body-sm text-body-sm shadow-xs border border-outline-variant/40 group"
          title="打开悬浮小窗模式 (440x580)"
        >
          <span className="material-symbols-outlined text-base group-hover:scale-110 transition-transform text-primary">
            picture_in_picture_alt
          </span>
          <span className="hidden sm:inline font-medium">小窗模式</span>
        </button>

        {/* Profile Avatar */}
        <div className="flex items-center gap-space-xs pl-space-xs">
          <div className="relative">
            <img
              alt="林舒心"
              className="w-8 h-8 rounded-full object-cover ring-2 ring-surface-container-high bg-primary-fixed"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBcjNn7ENVnSMFmNKduroWZcWW6lozIuXjHFLyK-Qh9Y42tFOkpCfTRPsEL2IXplKL-5wCv1dB80wsRmd03zjWhKAjpaLKG-fWROtbVXQiZ_pnkhsDOmNDnyD2FAL6GH9hKF2DTh3snOv_Muy2jKjnRlVUr3Uz-nYWhB33EEp2vskePuKZ8QkseCHge_y6pzhft2saWfRewrN1N4B_XUoTsEajrsJgu0qSI4wvqPluAP9F8mFNLTf-F"
              onError={(e) => {
                // Fallback avatar
                const target = e.currentTarget;
                target.style.display = 'none';
                if (target.nextElementSibling) {
                  (target.nextElementSibling as HTMLElement).style.display = 'flex';
                }
              }}
            />
            <div className="hidden w-8 h-8 rounded-full bg-primary text-white font-semibold text-xs items-center justify-center ring-2 ring-surface-container-high">
              舒心
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-secondary ring-2 ring-white" />
          </div>
          <div className="hidden lg:flex flex-col text-left">
            <span className="font-body-sm text-body-sm font-medium text-on-surface leading-none">
              林舒心
            </span>
            <span className="font-label-tag text-label-tag text-on-surface-variant leading-none mt-0.5">
              沉浸状态
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
