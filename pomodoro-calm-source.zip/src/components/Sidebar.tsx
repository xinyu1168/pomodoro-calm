import React from 'react';
import { NavigationPath } from '../types';

interface SidebarProps {
  currentPath: NavigationPath;
  onNavigate: (path: NavigationPath) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPath,
  onNavigate,
  isOpenMobile,
  onCloseMobile
}) => {
  const navItems = [
    {
      path: 'focus-timer' as NavigationPath,
      label: '专注计时',
      icon: 'timer'
    },
    {
      path: 'weekly-analytics' as NavigationPath,
      label: '周度统计',
      icon: 'insights'
    },
    {
      path: 'daily-breakdown' as NavigationPath,
      label: '每日明细',
      icon: 'calendar_today'
    },
    {
      path: 'customization-tags' as NavigationPath,
      label: '自定义设置',
      icon: 'tune'
    }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed left-0 top-0 h-full w-64 bg-surface-container-low z-50 flex flex-col justify-between shadow-[0_1px_8px_rgba(0,0,0,0.03)] border-r border-outline-variant/30 transition-transform duration-300 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex flex-col">
          {/* Mac window dots and version */}
          <div className="h-16 px-space-lg flex items-center justify-between border-b border-surface-container-high/60">
            <div className="flex items-center gap-space-sm">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-[#f87171] inline-block opacity-80 hover:opacity-100 transition-opacity cursor-pointer" title="关闭" />
                <span className="w-3 h-3 rounded-full bg-[#fbbf24] inline-block opacity-80 hover:opacity-100 transition-opacity cursor-pointer" title="最小化" />
                <span className="w-3 h-3 rounded-full bg-[#34d399] inline-block opacity-80 hover:opacity-100 transition-opacity cursor-pointer" title="全屏" />
              </div>
              <span className="ml-space-sm font-label-mono text-label-mono text-on-surface-variant/60 tracking-wider">
                CALM v2.4
              </span>
            </div>

            {/* Mobile close button */}
            <button
              onClick={onCloseMobile}
              className="lg:hidden p-1 text-on-surface-variant hover:text-on-surface"
            >
              <span className="material-symbols-outlined text-lg">close</span>
            </button>
          </div>

          {/* Navigation group */}
          <div className="px-space-md py-space-sm">
            <div className="px-space-sm mb-space-sm font-label-tag text-label-tag text-on-surface-variant uppercase tracking-widest opacity-70">
              空间导航
            </div>
            <nav className="flex flex-col gap-1">
              {navItems.map((item) => {
                const isActive = currentPath === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => {
                      onNavigate(item.path);
                      if (onCloseMobile) onCloseMobile();
                    }}
                    className={`flex items-center gap-space-sm px-space-md py-2.5 rounded-xl transition-all text-left w-full group ${
                      isActive
                        ? 'bg-primary-container text-on-primary-container font-headline-sm shadow-sm'
                        : 'text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface'
                    }`}
                  >
                    <span
                      className={`material-symbols-outlined text-lg transition-transform ${
                        isActive ? 'text-white' : 'text-on-surface-variant group-hover:scale-110'
                      }`}
                    >
                      {item.icon}
                    </span>
                    <span className="font-body-md text-body-md">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Bottom Mindfulness Mood Status Card */}
        <div className="p-space-md">
          <div className="bg-surface-container rounded-xl p-space-md flex flex-col gap-space-xs border border-outline-variant/30">
            <div className="flex items-center justify-between">
              <span className="font-label-tag text-label-tag text-on-surface-variant">
                今日心流心境
              </span>
              <span className="w-2 h-2 rounded-full bg-secondary animate-pulse" />
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
              温和如常，专注此刻呼吸与节奏。
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};
