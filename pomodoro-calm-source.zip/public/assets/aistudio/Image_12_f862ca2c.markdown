---
name: Warm Citrus Focus
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#584237'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#8c7164'
  outline-variant: '#e0c0b1'
  surface-tint: '#9d4300'
  primary: '#9d4300'
  on-primary: '#ffffff'
  primary-container: '#f97316'
  on-primary-container: '#582200'
  inverse-primary: '#ffb690'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fcd34d'
  on-secondary-container: '#725b00'
  tertiary: '#a73a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#ff6d2c'
  on-tertiary-container: '#5d1d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbca'
  primary-fixed-dim: '#ffb690'
  on-primary-fixed: '#341100'
  on-primary-fixed-variant: '#783200'
  secondary-fixed: '#ffe086'
  secondary-fixed-dim: '#eac33e'
  on-secondary-fixed: '#231b00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb599'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#7f2b00'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  headline-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
  headline-display-compact:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 36px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  timer-digits:
    fontFamily: JetBrains Mono
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
  timer-digits-mini:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 24px
  label-pill:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system expresses a vibrant, warm minimalist aesthetic tailored for a floating mini desktop Pomodoro and productivity tool. Designed to sit unobtrusively yet delightfully in the corner of a screen, the interface radiates optimism, emotional comfort, and focused energy.

- **Brand Personality**: Friendly, disciplined yet joyful, comforting, and sunny. It replaces intimidating clinical timers with a cheering desk companion.
- **Target Audience**: Creatives, knowledge workers, students, and digital craftspeople who appreciate tactile micro-apps and desire an anti-anxiety focus environment.
- **Visual Stance**: Tactile warm minimalism. Crisp typographic hierarchy meets luminous buttery yellow and zesty citrus orange tones, set on a cream paper canvas with soft borders and pill silhouettes. It delivers ultra-high glanceability and crisp legibility even when sized down to a tiny 240px floating widget.

## Colors

The palette balances buoyant warmth with crisp contrast, ensuring tiny timer readouts and status indicators stay razor-sharp against warm surfaces:

- **Canvas & Backdrops**:
  - Primary Base Canvas: `#FFFDF7` (Warm Paper Cream)
  - Surface Tint / Card Containers: `#FFFBEB` (Tender Cream Glow)
  - Secondary Inset Wells: `#FEF3C7` (Muted Butter)
- **Primary Energy**:
  - Primary Base: `#F97316` (Radiant Warm Citrus Orange)
  - Primary Hover / Pressed Accent: `#EA580C` (Sun-drenched Deep Orange)
- **Secondary Cheer**:
  - Soft Butter Yellow: `#FCD34D` (Crisp Butter Sun)
  - Light Butter Sheen: `#FDE68A` (Tender Pastel Yellow)
- **Neutral & Typographic Ink**:
  - Primary Ink: `#1F2937` (Rich Charcoal Slate — prevents harsh starkness of pure black while achieving high contrast)
  - Secondary Ink / Subtitles: `#4B5563`
  - Muted Glyphs / Counter Tracks: `#9CA3AF`
- **Boundaries & Dividers**:
  - Warm Dividing Stroke: `#FED7AA` (Soft Citrus Border)
  - Accent Muted Border: `#FDE68A` (Delicate Butter Trim)

## Typography

The type system blends friendly, geometric clarity with mechanical precision:
- **Display & Interface Copy (`Plus Jakarta Sans`)**: Soft terminals and balanced counter-forms offer human warmth and instant legibility at both mini-widget and expanded scales.
- **Numerical Time Displays & Metrics (`JetBrains Mono`)**: Strict tabular spacing prevents layout jitter during active countdowns and progress ticks in compact window modes.
- **Optical Adjustments**: Numeric timers use tight tracking (`-0.02em`) for cohesion, while micro labels and uppercase status tags employ looser tracking (`+0.05em`) to stay crystal clear on dense canvas tiles.

## Layout & Spacing

Because this system powers a floating desktop mini-application, spacing is optimized for density, spatial thrift, and edge padding:

- **Window Dimensions**:
  - `Mini Pip Mode`: 220px to 260px wide, single column stack.
  - `Standard Floating Mode`: 320px to 380px wide.
  - `Expanded Companion Mode`: 480px max width with optional task drawers.
- **Rhythm & Padding**:
  - Outer window margin: `space-lg` (16px) or `space-md` (12px) in mini view.
  - Inter-component stack: `space-sm` (8px) between micro cards and timer controls.
  - Internal card padding: `space-md` (12px) to maintain a light, uncluttered breathing room without wasting screen real estate.
- **Spatial Principles**: Strict auto-layout column orientation with dynamic height collapsing to fit discreetly next to active work windows.

## Elevation & Depth

Visual hierarchy uses warm, sun-cast ambient depth instead of heavy shadows or cold gray tints:

- **Ambient Sun Elevation**: Subtle dual-layer drop shadows tinted with warm honey orange: `box-shadow: 0 4px 14px -2px rgba(249, 115, 22, 0.08), 0 2px 6px -1px rgba(217, 119, 6, 0.05)`.
- **Floating Window Shell**: A layered warm border paired with soft ground glow: `0 12px 32px -4px rgba(234, 88, 12, 0.12), 0 0 0 1px #FED7AA`.
- **Tonal Stepping**: Depth is realized primarily through background shifts: base canvas (`#FFFDF7`) sits underneath card surfaces (`#FFFBEB`), framed with crisp yet soft strokes (`#FED7AA`).
- **Interactive Depress**: Clicked buttons flatten their offset shadow and push downwards by 1px to mimic tactile rubberized desktop keys.

## Shapes

The shape vocabulary emphasizes smooth pill geometry and organic friendliness:

- **Containers & Windows**: The mini app container utilizes a pill-influenced radius of `1.5rem` to `2rem` (24px–32px), creating a smooth pebble-like desktop object.
- **Interactive Elements & Tags**: Buttons, inputs, and state chips default to continuous pill contours (`rounded-full` / `9999px`), ensuring pleasant tactile affordances.
- **Inner Metric Panels**: Secondary timer dials and task boxes take a gentle `rounded-2xl` (16px) curvature, softening internal structural grids.

## Components

### Buttons
- **Primary Action (Start/Resume)**: Full pill shape (`rounded-full`), saturated Warm Citrus Orange background (`#F97316`), pure white text, zero border, and warm citrus ambient shadow. Hover shifts to `#EA580C`.
- **Secondary Action (Pause/Skip)**: Tender Butter Yellow background (`#FDE68A`), Charcoal text (`#1F2937`), subtle `#FED7AA` outline, tactile depress on active state.
- **Ghost/Mini Actions**: Transparent pill with soft hover fill (`#FEF3C7`), compact padding (`6px 12px`).

### Round Pill Tags
- **Structure**: Icon-free, continuous pill shape (`border-radius: 9999px`).
- **Typography**: `label-pill` (11px, weight 600).
- **Styling Variations**:
  - *Focus Session*: Background `#FEF3C7`, border `1px solid #FED7AA`, text `#EA580C`.
  - *Short Break*: Background `#ECFDF5`, border `1px solid #A7F3D0`, text `#047857`.
  - *Long Break*: Background `#EFF6FF`, border `1px solid #BFDBFE`, text `#1D4ED8`.
  - *Tag Label (Project/Task)*: Background `#FFFBEB`, border `1px solid #FED7AA`, text `#1F2937`.

### Cards & Container Panels
- Floating window wrapper uses `#FFFDF7` with a 1px `#FED7AA` perimeter border.
- Inner task cards use `#FFFBEB` with smooth 16px corners, 1px `#FED7AA` borders, and internal padding of 12px.

### Timer Display
- Central focal readout rendered in `JetBrains Mono` bold tabular numbers.
- Surrounded by an SVG circular track: background track `#FEF3C7` (stroke 4px), active fill progress track `#F97316` with smooth round cap.

### Form Inputs & Checkboxes
- **Task Input**: Pill container, background `#FFFDF7`, border `1px solid #FED7AA`, charcoal input text, placeholder `#9CA3AF`. Focus ring uses `#F97316` at 20% opacity.
- **Checkboxes**: Smooth rounded square (radius 6px) with `#FED7AA` border; when checked, fills with `#F97316` displaying a clean white stroke checkmark.

### Window Controls
- Floating header hosts minimal, soft window buttons (minimize, pin-to-top, close) styled as tiny 10px circular color chips with delicate hover states.