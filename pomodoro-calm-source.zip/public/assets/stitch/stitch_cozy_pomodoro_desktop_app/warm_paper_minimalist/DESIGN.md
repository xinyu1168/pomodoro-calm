---
name: Warm Paper Minimalist
colors:
  surface: '#fff8f5'
  surface-dim: '#e1d8d4'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf2ed'
  surface-container: '#f5ece7'
  surface-container-high: '#efe6e2'
  surface-container-highest: '#e9e1dc'
  on-surface: '#1e1b18'
  on-surface-variant: '#56423c'
  inverse-surface: '#34302c'
  inverse-on-surface: '#f8efea'
  outline: '#8a726a'
  outline-variant: '#ddc0b7'
  surface-tint: '#a0401c'
  primary: '#9d3e1a'
  on-primary: '#ffffff'
  primary-container: '#bd5630'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59c'
  secondary: '#446554'
  on-secondary: '#ffffff'
  secondary-container: '#c3e8d2'
  on-secondary-container: '#486a58'
  tertiary: '#97422b'
  on-tertiary: '#ffffff'
  tertiary-container: '#b65a41'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#802a05'
  secondary-fixed: '#c6ebd5'
  secondary-fixed-dim: '#aacfba'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#2c4d3d'
  tertiary-fixed: '#ffdbd2'
  tertiary-fixed-dim: '#ffb4a1'
  on-tertiary-fixed: '#3c0800'
  on-tertiary-fixed-variant: '#7c2e19'
  background: '#fff8f5'
  on-background: '#1e1b18'
  surface-variant: '#e9e1dc'
typography:
  display-timer:
    fontFamily: Plus Jakarta Sans
    fontSize: 112px
    fontWeight: '300'
    lineHeight: 112px
    letterSpacing: -0.03em
  display-timer-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 64px
    fontWeight: '300'
    lineHeight: 64px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-tag:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2rem
  margin: 1.5rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies a Japandi-inspired philosophy—a fusion of Scandinavian functional simplicity and Japanese *wabi-sabi* warmth. Built specifically for deep focus and mindful time management, the environment rejects clinical productivity aesthetics in favor of a tactile, paper-like desktop sanctuary.

### Emotional Resonance
- **Grounded Calm:** Reduces cognitive load and work-related friction through muted paper textures, non-jarring state shifts, and ample breathing room.
- **Mindful Cadence:** Treats work sessions not as rigid industrial metrics, but as natural intervals of intention and restorative rest.
- **Quiet Craft:** Leverages soft physical affordances, understated borders, and deliberate typography to evoke high-end stationery and warm desk objects.

## Colors

The palette balances warm organic substrates with earthy, intentional accents:

- **Canvas & Surface Tier:**
  - `Base Canvas`: `#FAF8F5` (warm oat cream) provides an unbleached, glare-free background.
  - `Surface Container`: `#F5F1EB` (milled grain) provides subtle framing for persistent panels.
  - `Card / Inset Background`: `#EFE9E1` (soft sand) defines modular task surfaces and interactive pods.
- **Accents:**
  - `Primary / Focus Active`: `#D96B43` (terracotta) marks primary focus intervals, current action triggers, and active progression bars.
  - `Secondary / Rest Active`: `#6B8E7B` (matcha / sage) designates short breaks and restorative intervals.
  - `Tertiary Accent`: `#E07A5F` (sunbaked clay) serves as an interactive hover and soft highlight shade for focus actions.
- **Typographic Hierarchy:**
  - `Text Primary`: `#2D2926` (sumi ink charcoal) guarantees AAA readability without the harshness of pure black.
  - `Text Muted`: `#5A544F` (warm stone) handles secondary metadata, interval cues, and keyboard shortcuts.
  - `Border / Line`: `#E3DDD3` creates whisper-soft delineation between stacked cards.

## Typography

The type scale combines **Plus Jakarta Sans** for smooth, welcoming geometric structure and **JetBrains Mono** for fixed-width temporal indicators and metrics.

- **Tabular Numerals:** All timer counters and numerical metrics in Plus Jakarta Sans must use `font-variant-numeric: tabular-nums` to prevent horizontal jitter during countdowns.
- **Timer Weight:** The display clock relies on light weight (`300`) at scale (`112px`) to dominate visual balance without appearing heavy or urgent.
- **Mono Utilities:** Short cycle counters, streak tallies, and hotkey indicators leverage `label-mono` for precision against the organic background.

## Layout & Spacing

A centralized fixed-fluid desktop model balances centered focus with contextual task drawers.

- **Application Canvas:** Max-width of `1280px` centered on wide viewports, with a prominent central focus core bounded at `640px`.
- **Three-Zone Rhythm:**
  - `Left Dock / Mini Drawer`: Collapsible project & tag taxonomy (`260px`).
  - `Center Stage`: Timer pedestal, active intention banner, and instant action dock.
  - `Right Utility`: Task queue and ambient session log (`340px`).
- **Responsive Adaptations:**
  - Desktop (>1024px): 3-column split view with 32px (`gutter-desktop`) gutters.
  - Tablet (768px - 1023px): Collapses to central timer with slide-over drawers for tasks.
  - Mobile (<768px): Single-column view with bottom navigation bar and fluid margins of `1.5rem`.

## Elevation & Depth

Visual hierarchy uses **tonal paper layering** and soft ambient light, avoiding harsh shadows or glossy layers.

- **Surface Tiers:**
  - `Canvas` (`#FAF8F5`): Flat underlying desk plane.
  - `Tier 1 Container` (`#F5F1EB`): Outlined by 1px solid `#E3DDD3`.
  - `Tier 2 Raised Pod` (`#EFE9E1`): Offset with soft diffused ground shadows: `0px 4px 20px -2px rgba(45, 41, 38, 0.04)`.
  - `Active Modal / Dialog`: Floating paper sheet elevated by `0px 16px 36px -4px rgba(45, 41, 38, 0.08)`, bounded by a 1px solid `#DCD4C8` edge.
- **State Feedback:** Focus session shifts tint the subtle 1px border of the main card to a warm terracotta glow (`rgba(217, 107, 67, 0.25)`), while break intervals smoothly transition borders to matcha tint (`rgba(107, 142, 123, 0.25)`).

## Shapes

The form language uses organic, stone-smoothed contours.

- **Primary Cards & Containers:** Standardized at `16px` to `24px` radius (`rounded-lg` and `rounded-xl`) to evoke river stones and rounded wooden trays.
- **Controls & Buttons:** Base inputs and buttons adopt `12px` to `16px` curvature.
- **Pill Badges & Mode Switchers:** Fully rounded pill shapes (`border-radius: 9999px`) for state indicators, interval switchers (Focus / Short Break / Long Break), and category chips.

## Components

### Buttons
- **Primary Focus Button:** Muted Terracotta (`#D96B43`) background, `#FFFFFF` text, `16px` radius, padding `16px 32px`. Hover state: `#E07A5F`. Subtle tap scale feedback (`0.98`).
- **Break Mode Button:** Sage Green (`#6B8E7B`) background, `#FFFFFF` text, retaining identical button tokens for rhythmic muscle memory.
- **Secondary Ghost Button:** `#EFE9E1` background, `#2D2926` text, 1px border in `#E3DDD3`. Hover: `#E7DFD5`.

### Chips & Tags
- **Interval Mode Pills:** Enclosed in a segmented pill container (`#EFE9E1`). The active state glides with a smooth spring transition using a raised `#FAF8F5` surface with soft shadow and `#2D2926` text. Inactive labels use `#5A544F`.
- **Contextual Task Chips:** Pill-shaped tags (`8px 14px`), background `#FAF8F5`, 1px border `#E3DDD3`, text `label-tag`.

### Lists & Tasks
- **Task Rows:** Flat surface (`#FAF8F5` resting on `#F5F1EB`), `12px` roundedness, separated by 8px gaps. Left-aligned custom circular checkbox, task title in `body-md`, and trailing mono estimate badge (`label-mono`).
- **Completed State:** Text transitions to `#5A544F` with clean strike-through; card background drops to 50% opacity.

### Checkboxes & Controls
- **Circular Checkboxes:** 20px round shape, 1.5px border `#DCD4C8`. On check: filled with `#D96B43` (or `#6B8E7B` if during break task), containing a white rounded tick icon.

### Cards
- **Main Timer Pedestal:** `#F5F1EB` background, `24px` radius, 1px solid `#E3DDD3`. Houses the tabular countdown, interval label, and fluid radial progress ring with an unhurried stroke design.
- **Session Summary Card:** Soft sand background (`#EFE9E1`), zero border, `16px` radius, housing warm data visualizations and daily milestone metrics.

### Ambient Progress Ring
- Minimal SVG circle with `stroke-linecap: round`. Track in `rgba(45, 41, 38, 0.05)`, fill stroke using `#D96B43` (Focus) and `#6B8E7B` (Break) with a smooth CSS duration transition of `1s linear`.