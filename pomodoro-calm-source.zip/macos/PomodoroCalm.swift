import AppKit
import WebKit
import Network

final class AppDelegate: NSObject, NSApplicationDelegate, WKScriptMessageHandler {
  private var window: NSWindow!
  private var webView: WKWebView!
  private var listener: NWListener?
  private let serverQueue = DispatchQueue(label: "com.pomodorocalm.local-server")
  private var isMini = false

  func applicationDidFinishLaunching(_ notification: Notification) {
    NSApp.setActivationPolicy(.regular)
    let config = WKWebViewConfiguration()
    config.userContentController.add(self, name: "pomodoro")
    webView = WKWebView(frame: .zero, configuration: config)
    webView.autoresizingMask = [.width, .height]
    webView.setValue(false, forKey: "drawsBackground")

    window = NSWindow(
      contentRect: NSRect(x: 0, y: 0, width: 1020, height: 760),
      styleMask: [.titled, .closable, .miniaturizable, .resizable],
      backing: .buffered,
      defer: false
    )
    window.title = "Pomodoro Calm"
    window.center()
    window.minSize = NSSize(width: 760, height: 560)
    window.backgroundColor = NSColor(calibratedRed: 1, green: 0.973, blue: 0.961, alpha: 1)
    window.contentView = webView
    window.isReleasedWhenClosed = false

    startLocalServer()
    window.makeKeyAndOrderFront(nil)
    NSApp.activate(ignoringOtherApps: true)
  }

  private func startLocalServer() {
    guard let root = Bundle.main.resourceURL?.appendingPathComponent("dist") else { return }
    do {
      // A stable loopback origin lets WKWebView keep localStorage between launches.
      let server = try NWListener(using: .tcp, on: NWEndpoint.Port(rawValue: 49328)!)
      listener = server
      server.newConnectionHandler = { [weak self] connection in
        connection.start(queue: self?.serverQueue ?? .global())
        self?.readRequest(connection, root: root)
      }
      server.stateUpdateHandler = { [weak self] state in
        guard case .ready = state, let port = server.port?.rawValue else { return }
        DispatchQueue.main.async {
          self?.webView.load(URLRequest(url: URL(string: "http://127.0.0.1:\(port)/")!))
        }
      }
      server.start(queue: serverQueue)
    } catch {
      NSLog("Pomodoro Calm local web server failed: %@", error.localizedDescription)
    }
  }

  private func readRequest(_ connection: NWConnection, root: URL) {
    connection.receive(minimumIncompleteLength: 1, maximumLength: 16_384) { [weak self] data, _, _, _ in
      guard let self, let data, let request = String(data: data, encoding: .utf8),
            let firstLine = request.components(separatedBy: "\r\n").first,
            let rawPath = firstLine.split(separator: " ").dropFirst().first else {
        connection.cancel(); return
      }
      let path = String(rawPath).split(separator: "?").first.map(String.init) ?? "/"
      let safePath = path.removingPercentEncoding ?? path
      let relative = safePath == "/" ? "index.html" : String(safePath.dropFirst())
      let file = root.appendingPathComponent(relative).standardizedFileURL
      guard file.path.hasPrefix(root.standardizedFileURL.path + "/"),
            let body = try? Data(contentsOf: file) else {
        self.send(Data("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".utf8), through: connection)
        return
      }
      let ext = file.pathExtension.lowercased()
      let mime: String
      switch ext {
      case "html": mime = "text/html; charset=utf-8"
      case "js", "mjs": mime = "text/javascript; charset=utf-8"
      case "css": mime = "text/css; charset=utf-8"
      case "json": mime = "application/json"
      case "svg": mime = "image/svg+xml"
      case "png": mime = "image/png"
      case "jpg", "jpeg": mime = "image/jpeg"
      case "woff", "woff2": mime = "font/\(ext)"
      default: mime = "application/octet-stream"
      }
      var response = Data("HTTP/1.1 200 OK\r\nContent-Type: \(mime)\r\nContent-Length: \(body.count)\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n".utf8)
      response.append(body)
      self.send(response, through: connection)
    }
  }

  private func send(_ data: Data, through connection: NWConnection) {
    connection.send(content: data, completion: .contentProcessed { _ in connection.cancel() })
  }

  func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
    guard let body = message.body as? [String: Any], body["action"] as? String == "mini",
          let enabled = body["enabled"] as? Bool else { return }
    setMiniMode(enabled)
  }

  private func setMiniMode(_ enabled: Bool) {
    guard isMini != enabled else { return }
    isMini = enabled
    if enabled {
      window.minSize = NSSize(width: 560, height: 280)
      window.setContentSize(NSSize(width: 660, height: 330))
      window.level = .floating
      window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
      window.title = "Pomodoro Calm · 专注小窗"
    } else {
      window.level = .normal
      window.collectionBehavior = [.managed]
      window.setContentSize(NSSize(width: 1020, height: 760))
      window.minSize = NSSize(width: 760, height: 560)
      window.title = "Pomodoro Calm"
    }
    window.center()
    window.makeKeyAndOrderFront(nil)
  }

  func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
