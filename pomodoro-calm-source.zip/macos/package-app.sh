#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APP="$ROOT/release/Pomodoro Calm.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/dist"
cp -R "$ROOT/dist/." "$APP/Contents/Resources/dist/"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleExecutable</key><string>PomodoroCalm</string>
  <key>CFBundleIdentifier</key><string>com.pomodorocalm.desktop</string>
  <key>CFBundleName</key><string>Pomodoro Calm</string>
  <key>CFBundleDisplayName</key><string>Pomodoro Calm</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>12.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSPrincipalClass</key><string>NSApplication</string>
</dict>
</plist>
PLIST
printf 'APPL????' > "$APP/Contents/PkgInfo"
mkdir -p "$ROOT/macos/.module-cache"
xcrun swiftc -O -module-cache-path "$ROOT/macos/.module-cache" -Xcc -fmodules-cache-path="$ROOT/macos/.module-cache" "$ROOT/macos/PomodoroCalm.swift" -o "$APP/Contents/MacOS/PomodoroCalm" -framework AppKit -framework WebKit -framework Network
chmod +x "$APP/Contents/MacOS/PomodoroCalm"
codesign --force --deep --sign - "$APP"
